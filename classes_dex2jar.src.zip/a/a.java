package a;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class a extends Exception
{
  private static final long a = 1L;
  private static final String b = "There were multiple errors.";
  private List<Throwable> c;

  public a(String paramString, List<? extends Throwable> paramList)
  {
  }

  public a(String paramString, Throwable[] paramArrayOfThrowable)
  {
    this(paramString, Arrays.asList(paramArrayOfThrowable));
  }

  public a(List<? extends Throwable> paramList)
  {
    this("There were multiple errors.", paramList);
  }

  public List<Throwable> a()
  {
    return this.c;
  }

  @Deprecated
  public List<Exception> b()
  {
    ArrayList localArrayList = new ArrayList();
    if (this.c == null);
    while (true)
    {
      return localArrayList;
      Iterator localIterator = this.c.iterator();
      while (localIterator.hasNext())
      {
        Throwable localThrowable = (Throwable)localIterator.next();
        if ((localThrowable instanceof Exception))
        {
          localArrayList.add((Exception)localThrowable);
          continue;
        }
        localArrayList.add(new Exception(localThrowable));
      }
    }
  }

  @Deprecated
  public Throwable[] c()
  {
    return (Throwable[])this.c.toArray(new Throwable[this.c.size()]);
  }

  public void printStackTrace(PrintStream paramPrintStream)
  {
    super.printStackTrace(paramPrintStream);
    int i = -1;
    Iterator localIterator = this.c.iterator();
    while (localIterator.hasNext())
    {
      Throwable localThrowable = (Throwable)localIterator.next();
      paramPrintStream.append("\n");
      paramPrintStream.append("  Inner throwable #");
      i++;
      paramPrintStream.append(Integer.toString(i));
      paramPrintStream.append(": ");
      localThrowable.printStackTrace(paramPrintStream);
      paramPrintStream.append("\n");
    }
  }

  public void printStackTrace(PrintWriter paramPrintWriter)
  {
    super.printStackTrace(paramPrintWriter);
    int i = -1;
    Iterator localIterator = this.c.iterator();
    while (localIterator.hasNext())
    {
      Throwable localThrowable = (Throwable)localIterator.next();
      paramPrintWriter.append("\n");
      paramPrintWriter.append("  Inner throwable #");
      i++;
      paramPrintWriter.append(Integer.toString(i));
      paramPrintWriter.append(": ");
      localThrowable.printStackTrace(paramPrintWriter);
      paramPrintWriter.append("\n");
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.a
 * JD-Core Version:    0.6.0
 */