package a;

import android.annotation.SuppressLint;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

final class b
{
  static final int a = 0;
  static final int b = 0;
  static final long c = 1L;
  private static final b d = new b();
  private static final int f = Runtime.getRuntime().availableProcessors();
  private final Executor e = new a(null);

  static
  {
    a = 1 + f;
    b = 1 + 2 * f;
  }

  public static ExecutorService a()
  {
    ThreadPoolExecutor localThreadPoolExecutor = new ThreadPoolExecutor(a, b, 1L, TimeUnit.SECONDS, new LinkedBlockingQueue());
    a(localThreadPoolExecutor, true);
    return localThreadPoolExecutor;
  }

  public static ExecutorService a(ThreadFactory paramThreadFactory)
  {
    ThreadPoolExecutor localThreadPoolExecutor = new ThreadPoolExecutor(a, b, 1L, TimeUnit.SECONDS, new LinkedBlockingQueue(), paramThreadFactory);
    a(localThreadPoolExecutor, true);
    return localThreadPoolExecutor;
  }

  @SuppressLint({"NewApi"})
  public static void a(ThreadPoolExecutor paramThreadPoolExecutor, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 9)
      paramThreadPoolExecutor.allowCoreThreadTimeOut(paramBoolean);
  }

  public static Executor b()
  {
    return d.e;
  }

  private static class a
    implements Executor
  {
    public void execute(Runnable paramRunnable)
    {
      new Handler(Looper.getMainLooper()).post(paramRunnable);
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.b
 * JD-Core Version:    0.6.0
 */