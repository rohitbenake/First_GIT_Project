package a;

import java.util.Locale;
import java.util.concurrent.CancellationException;

public class d
{
  private final f a;

  d(f paramf)
  {
    this.a = paramf;
  }

  public e a(Runnable paramRunnable)
  {
    return this.a.a(paramRunnable);
  }

  public boolean a()
  {
    return this.a.a();
  }

  public void b()
    throws CancellationException
  {
    this.a.d();
  }

  public String toString()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = getClass().getName();
    arrayOfObject[1] = Integer.toHexString(hashCode());
    arrayOfObject[2] = Boolean.toString(this.a.a());
    return String.format(localLocale, "%s@%s[cancellationRequested=%s]", arrayOfObject);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.d
 * JD-Core Version:    0.6.0
 */