package a;

import java.io.Closeable;

public class e
  implements Closeable
{
  private final Object a = new Object();
  private f b;
  private Runnable c;
  private boolean d;

  e(f paramf, Runnable paramRunnable)
  {
    this.b = paramf;
    this.c = paramRunnable;
  }

  private void b()
  {
    if (this.d)
      throw new IllegalStateException("Object already closed");
  }

  void a()
  {
    synchronized (this.a)
    {
      b();
      this.c.run();
      close();
      return;
    }
  }

  public void close()
  {
    synchronized (this.a)
    {
      if (this.d)
        return;
      this.d = true;
      this.b.a(this);
      this.b = null;
      this.c = null;
      return;
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.e
 * JD-Core Version:    0.6.0
 */