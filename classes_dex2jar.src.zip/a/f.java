package a;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class f
  implements Closeable
{
  private final Object a = new Object();
  private final List<e> b = new ArrayList();
  private final ScheduledExecutorService c = c.b();
  private ScheduledFuture<?> d;
  private boolean e;
  private boolean f;

  private void a(long paramLong, TimeUnit paramTimeUnit)
  {
    if (paramLong < -1L)
      throw new IllegalArgumentException("Delay must be >= -1");
    if (paramLong == 0L)
    {
      c();
      return;
    }
    synchronized (this.a)
    {
      if (this.e)
        return;
    }
    f();
    if (paramLong != -1L)
      this.d = this.c.schedule(new Runnable()
      {
        public void run()
        {
          synchronized (f.a(f.this))
          {
            f.a(f.this, null);
            f.this.c();
            return;
          }
        }
      }
      , paramLong, paramTimeUnit);
    monitorexit;
  }

  private void a(List<e> paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      ((e)localIterator.next()).a();
  }

  private void e()
  {
    if (this.f)
      throw new IllegalStateException("Object already closed");
  }

  private void f()
  {
    if (this.d != null)
    {
      this.d.cancel(true);
      this.d = null;
    }
  }

  e a(Runnable paramRunnable)
  {
    synchronized (this.a)
    {
      e();
      e locale = new e(this, paramRunnable);
      if (this.e)
      {
        locale.a();
        return locale;
      }
      this.b.add(locale);
    }
  }

  public void a(long paramLong)
  {
    a(paramLong, TimeUnit.MILLISECONDS);
  }

  void a(e parame)
  {
    synchronized (this.a)
    {
      e();
      this.b.remove(parame);
      return;
    }
  }

  public boolean a()
  {
    synchronized (this.a)
    {
      e();
      boolean bool = this.e;
      return bool;
    }
  }

  public d b()
  {
    synchronized (this.a)
    {
      e();
      d locald = new d(this);
      return locald;
    }
  }

  public void c()
  {
    synchronized (this.a)
    {
      e();
      if (this.e)
        return;
      f();
      this.e = true;
      ArrayList localArrayList = new ArrayList(this.b);
      a(localArrayList);
      return;
    }
  }

  public void close()
  {
    synchronized (this.a)
    {
      if (this.f)
        return;
      f();
      Iterator localIterator = this.b.iterator();
      if (localIterator.hasNext())
        ((e)localIterator.next()).close();
    }
    this.b.clear();
    this.f = true;
    monitorexit;
  }

  void d()
    throws CancellationException
  {
    synchronized (this.a)
    {
      e();
      if (this.e)
        throw new CancellationException();
    }
    monitorexit;
  }

  public String toString()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = getClass().getName();
    arrayOfObject[1] = Integer.toHexString(hashCode());
    arrayOfObject[2] = Boolean.toString(a());
    return String.format(localLocale, "%s@%s[cancellationRequested=%s]", arrayOfObject);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.f
 * JD-Core Version:    0.6.0
 */