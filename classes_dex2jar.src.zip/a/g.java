package a;

public class g<T>
{
  private T a;

  public g()
  {
  }

  public g(T paramT)
  {
    this.a = paramT;
  }

  public T a()
  {
    return this.a;
  }

  public void a(T paramT)
  {
    this.a = paramT;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.g
 * JD-Core Version:    0.6.0
 */