package a;

public class i extends RuntimeException
{
  public i(Exception paramException)
  {
    super("An exception was thrown by an Executor", paramException);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.i
 * JD-Core Version:    0.6.0
 */