package a;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class j<TResult>
{
  public static final ExecutorService a = c.a();
  public static final Executor b;
  private static final Executor c = c.c();
  private static volatile b d;
  private static j<?> m;
  private static j<Boolean> n;
  private static j<Boolean> o;
  private static j<?> p;
  private final Object e = new Object();
  private boolean f;
  private boolean g;
  private TResult h;
  private Exception i;
  private boolean j;
  private l k;
  private List<h<TResult, Void>> l = new ArrayList();

  static
  {
    b = b.b();
    m = new j(null);
    n = new j(Boolean.valueOf(true));
    o = new j(Boolean.valueOf(false));
    p = new j(true);
  }

  j()
  {
  }

  private j(TResult paramTResult)
  {
    b(paramTResult);
  }

  private j(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      l();
      return;
    }
    b(null);
  }

  public static b a()
  {
    return d;
  }

  public static j<Void> a(long paramLong)
  {
    return a(paramLong, c.b(), null);
  }

  public static j<Void> a(long paramLong, d paramd)
  {
    return a(paramLong, c.b(), paramd);
  }

  static j<Void> a(long paramLong, ScheduledExecutorService paramScheduledExecutorService, d paramd)
  {
    if ((paramd != null) && (paramd.a()))
      return i();
    if (paramLong <= 0L)
      return a(null);
    k localk = new k();
    ScheduledFuture localScheduledFuture = paramScheduledExecutorService.schedule(new Runnable(localk)
    {
      public void run()
      {
        this.a.a(null);
      }
    }
    , paramLong, TimeUnit.MILLISECONDS);
    if (paramd != null)
      paramd.a(new Runnable(localScheduledFuture, localk)
      {
        public void run()
        {
          this.a.cancel(true);
          this.b.b();
        }
      });
    return localk.a();
  }

  public static <TResult> j<TResult> a(Exception paramException)
  {
    k localk = new k();
    localk.b(paramException);
    return localk.a();
  }

  public static <TResult> j<TResult> a(TResult paramTResult)
  {
    if (paramTResult == null)
      return m;
    if ((paramTResult instanceof Boolean))
    {
      if (((Boolean)paramTResult).booleanValue())
        return n;
      return o;
    }
    k localk = new k();
    localk.b(paramTResult);
    return localk.a();
  }

  public static <TResult> j<j<TResult>> a(Collection<? extends j<TResult>> paramCollection)
  {
    if (paramCollection.size() == 0)
      return a(null);
    k localk = new k();
    AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      ((j)localIterator.next()).a(new h(localAtomicBoolean, localk)
      {
        public Void b(j<TResult> paramj)
        {
          if (this.a.compareAndSet(false, true))
            this.b.b(paramj);
          while (true)
          {
            return null;
            paramj.g();
          }
        }
      });
    return localk.a();
  }

  public static <TResult> j<TResult> a(Callable<TResult> paramCallable)
  {
    return a(paramCallable, a, null);
  }

  public static <TResult> j<TResult> a(Callable<TResult> paramCallable, d paramd)
  {
    return a(paramCallable, a, paramd);
  }

  public static <TResult> j<TResult> a(Callable<TResult> paramCallable, Executor paramExecutor)
  {
    return a(paramCallable, paramExecutor, null);
  }

  public static <TResult> j<TResult> a(Callable<TResult> paramCallable, Executor paramExecutor, d paramd)
  {
    k localk = new k();
    try
    {
      paramExecutor.execute(new Runnable(paramd, localk, paramCallable)
      {
        public void run()
        {
          if ((this.a != null) && (this.a.a()))
          {
            this.b.c();
            return;
          }
          try
          {
            this.b.b(this.c.call());
            return;
          }
          catch (CancellationException localCancellationException)
          {
            this.b.c();
            return;
          }
          catch (Exception localException)
          {
            this.b.b(localException);
          }
        }
      });
      return localk.a();
    }
    catch (Exception localException)
    {
      while (true)
        localk.b(new i(localException));
    }
  }

  public static void a(b paramb)
  {
    d = paramb;
  }

  public static <TResult> j<TResult>.a b()
  {
    j localj = new j();
    localj.getClass();
    return new a();
  }

  public static j<j<?>> b(Collection<? extends j<?>> paramCollection)
  {
    if (paramCollection.size() == 0)
      return a(null);
    k localk = new k();
    AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      ((j)localIterator.next()).a(new h(localAtomicBoolean, localk)
      {
        public Void b(j<Object> paramj)
        {
          if (this.a.compareAndSet(false, true))
            this.b.b(paramj);
          while (true)
          {
            return null;
            paramj.g();
          }
        }
      });
    return localk.a();
  }

  public static <TResult> j<TResult> b(Callable<TResult> paramCallable)
  {
    return a(paramCallable, c, null);
  }

  public static <TResult> j<TResult> b(Callable<TResult> paramCallable, d paramd)
  {
    return a(paramCallable, c, paramd);
  }

  public static <TResult> j<List<TResult>> c(Collection<? extends j<TResult>> paramCollection)
  {
    return d(paramCollection).c(new h(paramCollection)
    {
      public List<TResult> b(j<Void> paramj)
        throws Exception
      {
        Object localObject;
        if (this.a.size() == 0)
          localObject = Collections.emptyList();
        while (true)
        {
          return localObject;
          localObject = new ArrayList();
          Iterator localIterator = this.a.iterator();
          while (localIterator.hasNext())
            ((List)localObject).add(((j)localIterator.next()).f());
        }
      }
    });
  }

  private static <TContinuationResult, TResult> void c(k<TContinuationResult> paramk, h<TResult, TContinuationResult> paramh, j<TResult> paramj, Executor paramExecutor, d paramd)
  {
    try
    {
      paramExecutor.execute(new Runnable(paramd, paramk, paramh, paramj)
      {
        public void run()
        {
          if ((this.a != null) && (this.a.a()))
          {
            this.b.c();
            return;
          }
          try
          {
            Object localObject = this.c.a(this.d);
            this.b.b(localObject);
            return;
          }
          catch (CancellationException localCancellationException)
          {
            this.b.c();
            return;
          }
          catch (Exception localException)
          {
            this.b.b(localException);
          }
        }
      });
      return;
    }
    catch (Exception localException)
    {
      paramk.b(new i(localException));
    }
  }

  public static j<Void> d(Collection<? extends j<?>> paramCollection)
  {
    if (paramCollection.size() == 0)
      return a(null);
    k localk = new k();
    ArrayList localArrayList = new ArrayList();
    Object localObject = new Object();
    AtomicInteger localAtomicInteger = new AtomicInteger(paramCollection.size());
    AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      ((j)localIterator.next()).a(new h(localObject, localArrayList, localAtomicBoolean, localAtomicInteger, localk)
      {
        public Void b(j<Object> paramj)
        {
          if (paramj.e());
          synchronized (this.a)
          {
            this.b.add(paramj.g());
            if (paramj.d())
              this.c.set(true);
            if (this.d.decrementAndGet() == 0)
            {
              if (this.b.size() == 0)
                break label151;
              if (this.b.size() == 1)
                this.e.b((Exception)this.b.get(0));
            }
            else
            {
              return null;
            }
          }
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = Integer.valueOf(this.b.size());
          a locala = new a(String.format("There were %d exceptions.", arrayOfObject), this.b);
          this.e.b(locala);
          return null;
          label151: if (this.c.get())
          {
            this.e.c();
            return null;
          }
          this.e.b(null);
          return null;
        }
      });
    return localk.a();
  }

  private static <TContinuationResult, TResult> void d(k<TContinuationResult> paramk, h<TResult, j<TContinuationResult>> paramh, j<TResult> paramj, Executor paramExecutor, d paramd)
  {
    try
    {
      paramExecutor.execute(new Runnable(paramd, paramk, paramh, paramj)
      {
        public void run()
        {
          if ((this.a != null) && (this.a.a()))
          {
            this.b.c();
            return;
          }
          try
          {
            localj = (j)this.c.a(this.d);
            if (localj == null)
            {
              this.b.b(null);
              return;
            }
          }
          catch (CancellationException localCancellationException)
          {
            j localj;
            this.b.c();
            return;
            localj.a(new h()
            {
              public Void b(j<TContinuationResult> paramj)
              {
                if ((j.7.this.a != null) && (j.7.this.a.a()))
                {
                  j.7.this.b.c();
                  return null;
                }
                if (paramj.d())
                {
                  j.7.this.b.c();
                  return null;
                }
                if (paramj.e())
                {
                  j.7.this.b.b(paramj.g());
                  return null;
                }
                j.7.this.b.b(paramj.f());
                return null;
              }
            });
            return;
          }
          catch (Exception localException)
          {
            this.b.b(localException);
          }
        }
      });
      return;
    }
    catch (Exception localException)
    {
      paramk.b(new i(localException));
    }
  }

  public static <TResult> j<TResult> i()
  {
    return p;
  }

  private void m()
  {
    while (true)
    {
      h localh;
      synchronized (this.e)
      {
        Iterator localIterator = this.l.iterator();
        if (!localIterator.hasNext())
          break;
        localh = (h)localIterator.next();
      }
      try
      {
        localh.a(this);
      }
      catch (RuntimeException localRuntimeException)
      {
        throw localRuntimeException;
        localObject2 = finally;
        monitorexit;
        throw localObject2;
      }
      catch (Exception localException)
      {
        throw new RuntimeException(localException);
      }
    }
    this.l = null;
    monitorexit;
  }

  public <TContinuationResult> j<TContinuationResult> a(h<TResult, TContinuationResult> paramh)
  {
    return a(paramh, c, null);
  }

  public <TContinuationResult> j<TContinuationResult> a(h<TResult, TContinuationResult> paramh, d paramd)
  {
    return a(paramh, c, paramd);
  }

  public <TContinuationResult> j<TContinuationResult> a(h<TResult, TContinuationResult> paramh, Executor paramExecutor)
  {
    return a(paramh, paramExecutor, null);
  }

  public <TContinuationResult> j<TContinuationResult> a(h<TResult, TContinuationResult> paramh, Executor paramExecutor, d paramd)
  {
    k localk = new k();
    synchronized (this.e)
    {
      boolean bool = c();
      if (!bool)
        this.l.add(new h(localk, paramh, paramExecutor, paramd)
        {
          public Void b(j<TResult> paramj)
          {
            j.a(this.a, this.b, paramj, this.c, this.d);
            return null;
          }
        });
      if (bool)
        c(localk, paramh, this, paramExecutor, paramd);
      return localk.a();
    }
  }

  public j<Void> a(Callable<Boolean> paramCallable, h<Void, j<Void>> paramh)
  {
    return a(paramCallable, paramh, c, null);
  }

  public j<Void> a(Callable<Boolean> paramCallable, h<Void, j<Void>> paramh, d paramd)
  {
    return a(paramCallable, paramh, c, paramd);
  }

  public j<Void> a(Callable<Boolean> paramCallable, h<Void, j<Void>> paramh, Executor paramExecutor)
  {
    return a(paramCallable, paramh, paramExecutor, null);
  }

  public j<Void> a(Callable<Boolean> paramCallable, h<Void, j<Void>> paramh, Executor paramExecutor, d paramd)
  {
    g localg = new g();
    localg.a(new h(paramd, paramCallable, paramh, paramExecutor, localg)
    {
      public j<Void> b(j<Void> paramj)
        throws Exception
      {
        if ((this.a != null) && (this.a.a()))
          return j.i();
        if (((Boolean)this.b.call()).booleanValue())
          return j.a(null).d(this.c, this.d).d((h)this.e.a(), this.d);
        return j.a(null);
      }
    });
    return k().b((h)localg.a(), paramExecutor);
  }

  public boolean a(long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException
  {
    synchronized (this.e)
    {
      if (!c())
        this.e.wait(paramTimeUnit.toMillis(paramLong));
      boolean bool = c();
      return bool;
    }
  }

  public <TContinuationResult> j<TContinuationResult> b(h<TResult, j<TContinuationResult>> paramh)
  {
    return b(paramh, c, null);
  }

  public <TContinuationResult> j<TContinuationResult> b(h<TResult, j<TContinuationResult>> paramh, d paramd)
  {
    return b(paramh, c, paramd);
  }

  public <TContinuationResult> j<TContinuationResult> b(h<TResult, j<TContinuationResult>> paramh, Executor paramExecutor)
  {
    return b(paramh, paramExecutor, null);
  }

  public <TContinuationResult> j<TContinuationResult> b(h<TResult, j<TContinuationResult>> paramh, Executor paramExecutor, d paramd)
  {
    k localk = new k();
    synchronized (this.e)
    {
      boolean bool = c();
      if (!bool)
        this.l.add(new h(localk, paramh, paramExecutor, paramd)
        {
          public Void b(j<TResult> paramj)
          {
            j.b(this.a, this.b, paramj, this.c, this.d);
            return null;
          }
        });
      if (bool)
        d(localk, paramh, this, paramExecutor, paramd);
      return localk.a();
    }
  }

  boolean b(Exception paramException)
  {
    synchronized (this.e)
    {
      if (this.f)
        return false;
      this.f = true;
      this.i = paramException;
      this.j = false;
      this.e.notifyAll();
      m();
      if ((!this.j) && (a() != null))
        this.k = new l(this);
      return true;
    }
  }

  boolean b(TResult paramTResult)
  {
    synchronized (this.e)
    {
      if (this.f)
        return false;
      this.f = true;
      this.h = paramTResult;
      this.e.notifyAll();
      m();
      return true;
    }
  }

  public <TContinuationResult> j<TContinuationResult> c(h<TResult, TContinuationResult> paramh)
  {
    return c(paramh, c, null);
  }

  public <TContinuationResult> j<TContinuationResult> c(h<TResult, TContinuationResult> paramh, d paramd)
  {
    return c(paramh, c, paramd);
  }

  public <TContinuationResult> j<TContinuationResult> c(h<TResult, TContinuationResult> paramh, Executor paramExecutor)
  {
    return c(paramh, paramExecutor, null);
  }

  public <TContinuationResult> j<TContinuationResult> c(h<TResult, TContinuationResult> paramh, Executor paramExecutor, d paramd)
  {
    return b(new h(paramd, paramh)
    {
      public j<TContinuationResult> b(j<TResult> paramj)
      {
        if ((this.a != null) && (this.a.a()))
          return j.i();
        if (paramj.e())
          return j.a(paramj.g());
        if (paramj.d())
          return j.i();
        return paramj.a(this.b);
      }
    }
    , paramExecutor);
  }

  public boolean c()
  {
    synchronized (this.e)
    {
      boolean bool = this.f;
      return bool;
    }
  }

  public <TContinuationResult> j<TContinuationResult> d(h<TResult, j<TContinuationResult>> paramh)
  {
    return d(paramh, c);
  }

  public <TContinuationResult> j<TContinuationResult> d(h<TResult, j<TContinuationResult>> paramh, d paramd)
  {
    return d(paramh, c, paramd);
  }

  public <TContinuationResult> j<TContinuationResult> d(h<TResult, j<TContinuationResult>> paramh, Executor paramExecutor)
  {
    return d(paramh, paramExecutor, null);
  }

  public <TContinuationResult> j<TContinuationResult> d(h<TResult, j<TContinuationResult>> paramh, Executor paramExecutor, d paramd)
  {
    return b(new h(paramd, paramh)
    {
      public j<TContinuationResult> b(j<TResult> paramj)
      {
        if ((this.a != null) && (this.a.a()))
          return j.i();
        if (paramj.e())
          return j.a(paramj.g());
        if (paramj.d())
          return j.i();
        return paramj.b(this.b);
      }
    }
    , paramExecutor);
  }

  public boolean d()
  {
    synchronized (this.e)
    {
      boolean bool = this.g;
      return bool;
    }
  }

  public boolean e()
  {
    while (true)
    {
      synchronized (this.e)
      {
        if (g() != null)
        {
          i1 = 1;
          return i1;
        }
      }
      int i1 = 0;
    }
  }

  public TResult f()
  {
    synchronized (this.e)
    {
      Object localObject3 = this.h;
      return localObject3;
    }
  }

  public Exception g()
  {
    synchronized (this.e)
    {
      if (this.i != null)
      {
        this.j = true;
        if (this.k != null)
        {
          this.k.a();
          this.k = null;
        }
      }
      Exception localException = this.i;
      return localException;
    }
  }

  public void h()
    throws InterruptedException
  {
    synchronized (this.e)
    {
      if (!c())
        this.e.wait();
      return;
    }
  }

  public <TOut> j<TOut> j()
  {
    return this;
  }

  public j<Void> k()
  {
    return b(new h()
    {
      public j<Void> b(j<TResult> paramj)
        throws Exception
      {
        if (paramj.d())
          return j.i();
        if (paramj.e())
          return j.a(paramj.g());
        return j.a(null);
      }
    });
  }

  boolean l()
  {
    synchronized (this.e)
    {
      if (this.f)
        return false;
      this.f = true;
      this.g = true;
      this.e.notifyAll();
      m();
      return true;
    }
  }

  public class a extends k<TResult>
  {
    a()
    {
    }
  }

  public static abstract interface b
  {
    public abstract void a(j<?> paramj, m paramm);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.j
 * JD-Core Version:    0.6.0
 */