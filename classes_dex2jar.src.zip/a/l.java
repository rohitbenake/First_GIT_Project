package a;

class l
{
  private j<?> a;

  public l(j<?> paramj)
  {
    this.a = paramj;
  }

  public void a()
  {
    this.a = null;
  }

  protected void finalize()
    throws Throwable
  {
    try
    {
      j localj = this.a;
      if (localj != null)
      {
        j.b localb = j.a();
        if (localb != null)
          localb.a(localj, new m(localj.g()));
      }
      return;
    }
    finally
    {
      super.finalize();
    }
    throw localObject;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.l
 * JD-Core Version:    0.6.0
 */