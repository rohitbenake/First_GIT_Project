package a;

public class m extends RuntimeException
{
  public m(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     a.m
 * JD-Core Version:    0.6.0
 */