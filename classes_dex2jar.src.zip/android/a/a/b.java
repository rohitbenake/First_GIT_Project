package android.a.a;

import android.content.pm.ParceledListSlice;
import android.media.session.MediaSession.Token;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface b extends IInterface
{
  public abstract void a()
    throws RemoteException;

  public abstract void a(String paramString, ParceledListSlice paramParceledListSlice)
    throws RemoteException;

  public abstract void a(String paramString, MediaSession.Token paramToken, Bundle paramBundle)
    throws RemoteException;

  public static abstract class a extends Binder
    implements b
  {
    public static b a(IBinder paramIBinder)
    {
      return null;
    }

    public IBinder asBinder()
    {
      return null;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      return false;
    }

    private static class a
      implements b
    {
      a(IBinder paramIBinder)
      {
      }

      public void a()
        throws RemoteException
      {
      }

      public void a(String paramString, ParceledListSlice paramParceledListSlice)
        throws RemoteException
      {
      }

      public void a(String paramString, MediaSession.Token paramToken, Bundle paramBundle)
        throws RemoteException
      {
      }

      public IBinder asBinder()
      {
        return null;
      }

      public String b()
      {
        return null;
      }
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.a.a.b
 * JD-Core Version:    0.6.0
 */