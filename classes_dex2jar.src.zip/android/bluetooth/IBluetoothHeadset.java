package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IBluetoothHeadset extends IInterface
{
  public abstract boolean acceptIncomingConnect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract void clccResponse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, String paramString, int paramInt5)
    throws RemoteException;

  public abstract boolean connect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean connectAudio()
    throws RemoteException;

  public abstract boolean connectHeadset(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean disconnect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean disconnectAudio()
    throws RemoteException;

  public abstract boolean disconnectHeadset(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract int getAudioState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract int getBatteryUsageHint(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract List<BluetoothDevice> getConnectedDevices()
    throws RemoteException;

  public abstract int getConnectionState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
    throws RemoteException;

  public abstract int getPriority(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract int getState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean isAudioConnected(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean isAudioOn()
    throws RemoteException;

  public abstract void phoneStateChanged(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4)
    throws RemoteException;

  public abstract boolean rejectIncomingConnect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean sendVendorSpecificResultCode(BluetoothDevice paramBluetoothDevice, String paramString1, String paramString2)
    throws RemoteException;

  public abstract boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
    throws RemoteException;

  public abstract boolean startScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean startVoiceRecognition(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean stopScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public abstract boolean stopVoiceRecognition(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;

  public static abstract class Stub extends Binder
    implements IBluetoothHeadset
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetoothHeadset";
    static final int TRANSACTION_acceptIncomingConnect = 16;
    static final int TRANSACTION_clccResponse = 25;
    static final int TRANSACTION_connect = 1;
    static final int TRANSACTION_connectAudio = 20;
    static final int TRANSACTION_connectHeadset = 2;
    static final int TRANSACTION_disconnect = 3;
    static final int TRANSACTION_disconnectAudio = 21;
    static final int TRANSACTION_disconnectHeadset = 4;
    static final int TRANSACTION_getAudioState = 18;
    static final int TRANSACTION_getBatteryUsageHint = 15;
    static final int TRANSACTION_getConnectedDevices = 5;
    static final int TRANSACTION_getConnectionState = 7;
    static final int TRANSACTION_getDevicesMatchingConnectionStates = 6;
    static final int TRANSACTION_getPriority = 10;
    static final int TRANSACTION_getState = 8;
    static final int TRANSACTION_isAudioConnected = 13;
    static final int TRANSACTION_isAudioOn = 19;
    static final int TRANSACTION_phoneStateChanged = 24;
    static final int TRANSACTION_rejectIncomingConnect = 17;
    static final int TRANSACTION_sendVendorSpecificResultCode = 14;
    static final int TRANSACTION_setPriority = 9;
    static final int TRANSACTION_startScoUsingVirtualVoiceCall = 22;
    static final int TRANSACTION_startVoiceRecognition = 11;
    static final int TRANSACTION_stopScoUsingVirtualVoiceCall = 23;
    static final int TRANSACTION_stopVoiceRecognition = 12;

    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetoothHeadset");
    }

    public static IBluetoothHeadset asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetoothHeadset");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetoothHeadset)))
        return (IBluetoothHeadset)localIInterface;
      return new Proxy(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("android.bluetooth.IBluetoothHeadset");
        return true;
      case 1:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice18;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice18 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool17 = connect(localBluetoothDevice18);
          paramParcel2.writeNoException();
          if (!bool17)
            break label299;
        }
        for (int i20 = 1; ; i20 = 0)
        {
          paramParcel2.writeInt(i20);
          return true;
          localBluetoothDevice18 = null;
          break;
        }
      case 2:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice17;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice17 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool16 = connectHeadset(localBluetoothDevice17);
          paramParcel2.writeNoException();
          if (!bool16)
            break label366;
        }
        for (int i19 = 1; ; i19 = 0)
        {
          paramParcel2.writeInt(i19);
          return true;
          localBluetoothDevice17 = null;
          break;
        }
      case 3:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice16;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice16 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool15 = disconnect(localBluetoothDevice16);
          paramParcel2.writeNoException();
          if (!bool15)
            break label433;
        }
        for (int i18 = 1; ; i18 = 0)
        {
          paramParcel2.writeInt(i18);
          return true;
          localBluetoothDevice16 = null;
          break;
        }
      case 4:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice15;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice15 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool14 = disconnectHeadset(localBluetoothDevice15);
          paramParcel2.writeNoException();
          if (!bool14)
            break label500;
        }
        for (int i17 = 1; ; i17 = 0)
        {
          paramParcel2.writeInt(i17);
          return true;
          localBluetoothDevice15 = null;
          break;
        }
      case 5:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        List localList2 = getConnectedDevices();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList2);
        return true;
      case 6:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        List localList1 = getDevicesMatchingConnectionStates(paramParcel1.createIntArray());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList1);
        return true;
      case 7:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0);
        for (BluetoothDevice localBluetoothDevice14 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1); ; localBluetoothDevice14 = null)
        {
          int i16 = getConnectionState(localBluetoothDevice14);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i16);
          return true;
        }
      case 8:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0);
        for (BluetoothDevice localBluetoothDevice13 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1); ; localBluetoothDevice13 = null)
        {
          int i15 = getState(localBluetoothDevice13);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i15);
          return true;
        }
      case 9:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice12;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice12 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool13 = setPriority(localBluetoothDevice12, paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (!bool13)
            break label729;
        }
        for (int i14 = 1; ; i14 = 0)
        {
          paramParcel2.writeInt(i14);
          return true;
          localBluetoothDevice12 = null;
          break;
        }
      case 10:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0);
        for (BluetoothDevice localBluetoothDevice11 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1); ; localBluetoothDevice11 = null)
        {
          int i13 = getPriority(localBluetoothDevice11);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i13);
          return true;
        }
      case 11:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice10;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice10 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool12 = startVoiceRecognition(localBluetoothDevice10);
          paramParcel2.writeNoException();
          if (!bool12)
            break label849;
        }
        for (int i12 = 1; ; i12 = 0)
        {
          paramParcel2.writeInt(i12);
          return true;
          localBluetoothDevice10 = null;
          break;
        }
      case 12:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice9;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice9 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool11 = stopVoiceRecognition(localBluetoothDevice9);
          paramParcel2.writeNoException();
          if (!bool11)
            break label916;
        }
        for (int i11 = 1; ; i11 = 0)
        {
          paramParcel2.writeInt(i11);
          return true;
          localBluetoothDevice9 = null;
          break;
        }
      case 13:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice8;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice8 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool10 = isAudioConnected(localBluetoothDevice8);
          paramParcel2.writeNoException();
          if (!bool10)
            break label983;
        }
        for (int i10 = 1; ; i10 = 0)
        {
          paramParcel2.writeInt(i10);
          return true;
          localBluetoothDevice8 = null;
          break;
        }
      case 14:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice7;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice7 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool9 = sendVendorSpecificResultCode(localBluetoothDevice7, paramParcel1.readString(), paramParcel1.readString());
          paramParcel2.writeNoException();
          if (!bool9)
            break label1058;
        }
        for (int i9 = 1; ; i9 = 0)
        {
          paramParcel2.writeInt(i9);
          return true;
          localBluetoothDevice7 = null;
          break;
        }
      case 15:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0);
        for (BluetoothDevice localBluetoothDevice6 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1); ; localBluetoothDevice6 = null)
        {
          int i8 = getBatteryUsageHint(localBluetoothDevice6);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i8);
          return true;
        }
      case 16:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice5;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice5 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool8 = acceptIncomingConnect(localBluetoothDevice5);
          paramParcel2.writeNoException();
          if (!bool8)
            break label1178;
        }
        for (int i7 = 1; ; i7 = 0)
        {
          paramParcel2.writeInt(i7);
          return true;
          localBluetoothDevice5 = null;
          break;
        }
      case 17:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice4;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice4 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool7 = rejectIncomingConnect(localBluetoothDevice4);
          paramParcel2.writeNoException();
          if (!bool7)
            break label1245;
        }
        for (int i6 = 1; ; i6 = 0)
        {
          paramParcel2.writeInt(i6);
          return true;
          localBluetoothDevice4 = null;
          break;
        }
      case 18:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0);
        for (BluetoothDevice localBluetoothDevice3 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1); ; localBluetoothDevice3 = null)
        {
          int i5 = getAudioState(localBluetoothDevice3);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i5);
          return true;
        }
      case 19:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        boolean bool6 = isAudioOn();
        paramParcel2.writeNoException();
        if (bool6);
        for (int i4 = 1; ; i4 = 0)
        {
          paramParcel2.writeInt(i4);
          return true;
        }
      case 20:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        boolean bool5 = connectAudio();
        paramParcel2.writeNoException();
        if (bool5);
        for (int i3 = 1; ; i3 = 0)
        {
          paramParcel2.writeInt(i3);
          return true;
        }
      case 21:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        boolean bool4 = disconnectAudio();
        paramParcel2.writeNoException();
        if (bool4);
        for (int i2 = 1; ; i2 = 0)
        {
          paramParcel2.writeInt(i2);
          return true;
        }
      case 22:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice2;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice2 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool3 = startScoUsingVirtualVoiceCall(localBluetoothDevice2);
          paramParcel2.writeNoException();
          if (!bool3)
            break label1479;
        }
        for (int i1 = 1; ; i1 = 0)
        {
          paramParcel2.writeInt(i1);
          return true;
          localBluetoothDevice2 = null;
          break;
        }
      case 23:
        label1178: paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice1;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice1 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool2 = stopScoUsingVirtualVoiceCall(localBluetoothDevice1);
          paramParcel2.writeNoException();
          if (!bool2)
            break label1546;
        }
        label1546: for (int n = 1; ; n = 0)
        {
          paramParcel2.writeInt(n);
          return true;
          localBluetoothDevice1 = null;
          break;
        }
      case 24:
        label299: label366: label500: paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        label433: label729: label1245: phoneStateChanged(paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readString(), paramParcel1.readInt());
        label849: label983: paramParcel2.writeNoException();
        label916: label1058: label1479: return true;
      case 25:
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
      int i = paramParcel1.readInt();
      int j = paramParcel1.readInt();
      int k = paramParcel1.readInt();
      int m = paramParcel1.readInt();
      if (paramParcel1.readInt() != 0);
      for (boolean bool1 = true; ; bool1 = false)
      {
        clccResponse(i, j, k, m, bool1, paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      }
    }

    private static class Proxy
      implements IBluetoothHeadset
    {
      private IBinder mRemote;

      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }

      public boolean acceptIncomingConnect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(16, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public IBinder asBinder()
      {
        return this.mRemote;
      }

      public void clccResponse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, String paramString, int paramInt5)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeInt(paramInt4);
          int i = 0;
          if (paramBoolean)
            i = 1;
          localParcel1.writeInt(i);
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt5);
          this.mRemote.transact(25, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean connect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(1, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean connectAudio()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(20, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = 0;
          if (i != 0)
            j = 1;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean connectHeadset(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(2, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean disconnect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(3, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean disconnectAudio()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(21, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = 0;
          if (i != 0)
            j = 1;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean disconnectHeadset(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(4, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public int getAudioState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          if (paramBluetoothDevice != null)
          {
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.mRemote.transact(18, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int i = localParcel2.readInt();
            return i;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getBatteryUsageHint(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          if (paramBluetoothDevice != null)
          {
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.mRemote.transact(15, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int i = localParcel2.readInt();
            return i;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public List<BluetoothDevice> getConnectedDevices()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getConnectionState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          if (paramBluetoothDevice != null)
          {
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.mRemote.transact(7, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int i = localParcel2.readInt();
            return i;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          localParcel1.writeIntArray(paramArrayOfInt);
          this.mRemote.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetoothHeadset";
      }

      public int getPriority(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          if (paramBluetoothDevice != null)
          {
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.mRemote.transact(10, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int i = localParcel2.readInt();
            return i;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          if (paramBluetoothDevice != null)
          {
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.mRemote.transact(8, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int i = localParcel2.readInt();
            return i;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean isAudioConnected(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(13, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean isAudioOn()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(19, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = 0;
          if (i != 0)
            j = 1;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void phoneStateChanged(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt4);
          this.mRemote.transact(24, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean rejectIncomingConnect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(17, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean sendVendorSpecificResultCode(BluetoothDevice paramBluetoothDevice, String paramString1, String paramString2)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            localParcel1.writeString(paramString1);
            localParcel1.writeString(paramString2);
            this.mRemote.transact(14, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            localParcel1.writeInt(paramInt);
            this.mRemote.transact(9, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean startScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(22, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean startVoiceRecognition(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(11, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean stopScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(23, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }

      public boolean stopVoiceRecognition(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice == null)
              continue;
            localParcel1.writeInt(1);
            paramBluetoothDevice.writeToParcel(localParcel1, 0);
            this.mRemote.transact(12, localParcel1, localParcel2, 0);
            localParcel2.readException();
            int j = localParcel2.readInt();
            if (j != 0)
            {
              return i;
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          i = 0;
        }
      }
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.bluetooth.IBluetoothHeadset
 * JD-Core Version:    0.6.0
 */