package android.content.pm;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import java.util.List;

public class ParceledListSlice<T extends Parcelable>
  implements Parcelable
{
  public static final Parcelable.ClassLoaderCreator<ParceledListSlice> CREATOR = new Parcelable.ClassLoaderCreator()
  {
    public ParceledListSlice createFromParcel(Parcel paramParcel)
    {
      return null;
    }

    public ParceledListSlice createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      return null;
    }

    public ParceledListSlice[] newArray(int paramInt)
    {
      return null;
    }
  };

  private ParceledListSlice(Parcel paramParcel, ClassLoader paramClassLoader)
  {
  }

  public ParceledListSlice(List<T> paramList)
  {
  }

  private static void verifySameType(Class<?> paramClass1, Class<?> paramClass2)
  {
  }

  public int describeContents()
  {
    return 0;
  }

  public List<T> getList()
  {
    return null;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.content.pm.ParceledListSlice
 * JD-Core Version:    0.6.0
 */