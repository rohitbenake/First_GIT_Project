package android.support.multidex;

public final class a
{
  public static final boolean a = false;
  public static final String b = "android.support.multidex";
  public static final String c = "release";
  public static final String d = "";
  public static final int e = -1;
  public static final String f = "";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.multidex.a
 * JD-Core Version:    0.6.0
 */