package android.support.v4.animation;

public abstract interface AnimatorListenerCompat
{
  public abstract void onAnimationCancel(ValueAnimatorCompat paramValueAnimatorCompat);

  public abstract void onAnimationEnd(ValueAnimatorCompat paramValueAnimatorCompat);

  public abstract void onAnimationRepeat(ValueAnimatorCompat paramValueAnimatorCompat);

  public abstract void onAnimationStart(ValueAnimatorCompat paramValueAnimatorCompat);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.animation.AnimatorListenerCompat
 * JD-Core Version:    0.6.0
 */