package android.support.v4.app;

import android.content.Intent;
import android.support.a.j;
import android.support.a.k;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class ActivityHostCallbacks extends FragmentHostCallback<FragmentActivity>
{
  private FragmentActivity activity;

  public ActivityHostCallbacks(FragmentActivity paramFragmentActivity)
  {
    super(paramFragmentActivity);
    this.activity = paramFragmentActivity;
    setWindow(paramFragmentActivity.getWindow());
  }

  public void onAttachFragment(Fragment paramFragment)
  {
    this.activity.onAttachFragment(paramFragment);
  }

  public void onDump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    this.activity.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }

  @k
  public View onFindViewById(int paramInt)
  {
    return this.activity.findViewById(paramInt);
  }

  public FragmentActivity onGetHost()
  {
    return this.activity;
  }

  public LayoutInflater onGetLayoutInflater()
  {
    return this.activity.getLayoutInflater().cloneInContext(this.activity);
  }

  public int onGetWindowAnimations()
  {
    Window localWindow = this.activity.getWindow();
    if (localWindow == null)
      return 0;
    return localWindow.getAttributes().windowAnimations;
  }

  public boolean onHasView()
  {
    Window localWindow = this.activity.getWindow();
    return (localWindow != null) && (localWindow.peekDecorView() != null);
  }

  public boolean onHasWindowAnimations()
  {
    return this.activity.getWindow() != null;
  }

  public void onRequestPermissionsFromFragment(@j Fragment paramFragment, @j String[] paramArrayOfString, int paramInt)
  {
    this.activity.requestPermissionsFromFragment(paramFragment, paramArrayOfString, paramInt);
  }

  public boolean onShouldSaveFragmentState(Fragment paramFragment)
  {
    return !this.activity.isFinishing();
  }

  public boolean onShouldShowRequestPermissionRationale(@j String paramString)
  {
    return ActivityCompat.shouldShowRequestPermissionRationale(this.activity, paramString);
  }

  public void onStartActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt)
  {
    this.activity.startActivityFromFragment(paramFragment, paramIntent, paramInt);
  }

  public void onSupportInvalidateOptionsMenu()
  {
    this.activity.supportInvalidateOptionsMenu();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ActivityHostCallbacks
 * JD-Core Version:    0.6.0
 */