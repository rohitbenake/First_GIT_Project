package android.support.v4.app;

import android.app.ActivityManager;
import android.os.Build.VERSION;
import android.support.a.j;

public final class ActivityManagerCompat
{
  public static boolean isLowRamDevice(@j ActivityManager paramActivityManager)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return ActivityManagerCompatKitKat.isLowRamDevice(paramActivityManager);
    return false;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ActivityManagerCompat
 * JD-Core Version:    0.6.0
 */