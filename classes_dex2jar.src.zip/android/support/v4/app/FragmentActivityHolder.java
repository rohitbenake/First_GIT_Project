package android.support.v4.app;

public class FragmentActivityHolder
{
  private static FragmentActivityHolder sInstance = new FragmentActivityHolder();
  private FragmentActivity fragmentActivity;

  public static FragmentActivityHolder getInstance()
  {
    return sInstance;
  }

  public FragmentActivity getFragmentActivity()
  {
    return this.fragmentActivity;
  }

  public void setFragmentActivity(FragmentActivity paramFragmentActivity)
  {
    this.fragmentActivity = paramFragmentActivity;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentActivityHolder
 * JD-Core Version:    0.6.0
 */