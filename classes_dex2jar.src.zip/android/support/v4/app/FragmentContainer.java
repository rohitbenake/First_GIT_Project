package android.support.v4.app;

import android.support.a.g;
import android.support.a.k;
import android.view.View;
import android.view.Window;

public abstract class FragmentContainer
{
  private Window window;

  public Window getWindow()
  {
    return this.window;
  }

  @k
  public abstract View onFindViewById(@g int paramInt);

  public abstract boolean onHasView();

  public void setWindow(Window paramWindow)
  {
    this.window = paramWindow;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentContainer
 * JD-Core Version:    0.6.0
 */