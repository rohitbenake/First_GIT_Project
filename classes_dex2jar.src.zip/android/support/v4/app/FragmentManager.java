package android.support.v4.app;

import android.os.Bundle;
import android.support.a.g;
import android.support.a.m;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class FragmentManager
{
  public static final int POP_BACK_STACK_INCLUSIVE = 1;

  public static void enableDebugLogging(boolean paramBoolean)
  {
    FragmentManagerImpl.DEBUG = paramBoolean;
  }

  public abstract void addOnBackStackChangedListener(OnBackStackChangedListener paramOnBackStackChangedListener);

  public abstract FragmentTransaction beginTransaction();

  public abstract void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);

  public abstract boolean executePendingTransactions();

  public abstract Fragment findFragmentById(@g int paramInt);

  public abstract Fragment findFragmentByTag(String paramString);

  public abstract BackStackEntry getBackStackEntryAt(int paramInt);

  public abstract int getBackStackEntryCount();

  public abstract Fragment getFragment(Bundle paramBundle, String paramString);

  public abstract List<Fragment> getFragments();

  public abstract FragmentHostCallback getHost();

  public abstract boolean isDestroyed();

  public abstract boolean isPendingActionWillExecuteOrExecuting();

  @Deprecated
  public FragmentTransaction openTransaction()
  {
    return beginTransaction();
  }

  public abstract void popBackStack();

  public abstract void popBackStack(int paramInt1, int paramInt2);

  public abstract void popBackStack(String paramString, int paramInt);

  public abstract boolean popBackStackImmediate();

  public abstract boolean popBackStackImmediate(int paramInt1, int paramInt2);

  public abstract boolean popBackStackImmediate(String paramString, int paramInt);

  public abstract void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment);

  public abstract void removeOnBackStackChangedListener(OnBackStackChangedListener paramOnBackStackChangedListener);

  public abstract Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment);

  public static abstract interface BackStackEntry
  {
    public abstract CharSequence getBreadCrumbShortTitle();

    @m
    public abstract int getBreadCrumbShortTitleRes();

    public abstract CharSequence getBreadCrumbTitle();

    @m
    public abstract int getBreadCrumbTitleRes();

    public abstract int getId();

    public abstract String getName();
  }

  public static abstract interface OnBackStackChangedListener
  {
    public abstract void onBackStackChanged();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentManager
 * JD-Core Version:    0.6.0
 */