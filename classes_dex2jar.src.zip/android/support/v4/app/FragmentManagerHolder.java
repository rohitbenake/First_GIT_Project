package android.support.v4.app;

import android.util.Log;

public class FragmentManagerHolder
{
  private static volatile FragmentManagerHolder sInstance = null;
  private FragmentManagerImpl mFragmentManager = null;

  private FragmentManagerHolder()
  {
    Log.v("FragmentManager", "FragmentManagerHolder init() mFragmentManager=" + this.mFragmentManager);
  }

  public static FragmentManagerHolder getInstance()
  {
    if (sInstance == null)
      monitorenter;
    try
    {
      if (sInstance == null)
        sInstance = new FragmentManagerHolder();
      return sInstance;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void destroy()
  {
    sInstance = null;
  }

  public FragmentManagerImpl getFragmentManagerImpl()
  {
    return this.mFragmentManager;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentManagerHolder
 * JD-Core Version:    0.6.0
 */