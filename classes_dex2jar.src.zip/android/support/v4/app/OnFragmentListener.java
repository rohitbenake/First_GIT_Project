package android.support.v4.app;

import android.app.Dialog;
import android.view.Window;

public abstract interface OnFragmentListener
{
  public abstract void attachHost();

  public abstract void bindDialog(Dialog paramDialog);

  public abstract FragmentManager getSupportFragmentManager();

  public abstract void onFragmentStart();

  public abstract void onFragmentStop();

  public abstract void setFragmentWindow(Window paramWindow);

  public abstract void setVehicleConnected(boolean paramBoolean);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.OnFragmentListener
 * JD-Core Version:    0.6.0
 */