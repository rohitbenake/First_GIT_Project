package android.support.v4.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.a.c;
import android.support.a.d;
import android.support.a.e;
import android.support.a.j;
import android.support.a.k;

public class ResourcesCompat
{
  @c
  public static int getColor(@j Resources paramResources, @d int paramInt, @k Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 23)
      return ResourcesCompatApi23.getColor(paramResources, paramInt, paramTheme);
    return paramResources.getColor(paramInt);
  }

  @k
  public static ColorStateList getColorStateList(@j Resources paramResources, @d int paramInt, @k Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 23)
      return ResourcesCompatApi23.getColorStateList(paramResources, paramInt, paramTheme);
    return paramResources.getColorStateList(paramInt);
  }

  @k
  public static Drawable getDrawable(@j Resources paramResources, @e int paramInt, @k Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 21)
      return ResourcesCompatApi21.getDrawable(paramResources, paramInt, paramTheme);
    return paramResources.getDrawable(paramInt);
  }

  @k
  public static Drawable getDrawableForDensity(@j Resources paramResources, @e int paramInt1, int paramInt2, @k Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 21)
      return ResourcesCompatApi21.getDrawableForDensity(paramResources, paramInt1, paramInt2, paramTheme);
    if (Build.VERSION.SDK_INT >= 15)
      return ResourcesCompatIcsMr1.getDrawableForDensity(paramResources, paramInt1, paramInt2);
    return paramResources.getDrawable(paramInt1);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.content.res.ResourcesCompat
 * JD-Core Version:    0.6.0
 */