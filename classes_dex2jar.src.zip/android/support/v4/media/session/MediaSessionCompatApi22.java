package android.support.v4.media.session;

import android.media.session.MediaSession;

class MediaSessionCompatApi22
{
  public static void setRatingType(Object paramObject, int paramInt)
  {
    ((MediaSession)paramObject).setRatingType(paramInt);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.MediaSessionCompatApi22
 * JD-Core Version:    0.6.0
 */