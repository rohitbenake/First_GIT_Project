package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.support.a.k;

public abstract interface TintableBackgroundView
{
  @k
  public abstract ColorStateList getSupportBackgroundTintList();

  @k
  public abstract PorterDuff.Mode getSupportBackgroundTintMode();

  public abstract void setSupportBackgroundTintList(@k ColorStateList paramColorStateList);

  public abstract void setSupportBackgroundTintMode(@k PorterDuff.Mode paramMode);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.TintableBackgroundView
 * JD-Core Version:    0.6.0
 */