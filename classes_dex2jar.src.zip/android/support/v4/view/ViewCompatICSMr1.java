package android.support.v4.view;

import android.view.View;

class ViewCompatICSMr1
{
  public static boolean hasOnClickListeners(View paramView)
  {
    return paramView.hasOnClickListeners();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompatICSMr1
 * JD-Core Version:    0.6.0
 */