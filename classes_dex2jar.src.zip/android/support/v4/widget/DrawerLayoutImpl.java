package android.support.v4.widget;

abstract interface DrawerLayoutImpl
{
  public abstract void setChildInsets(Object paramObject, boolean paramBoolean);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.DrawerLayoutImpl
 * JD-Core Version:    0.6.0
 */