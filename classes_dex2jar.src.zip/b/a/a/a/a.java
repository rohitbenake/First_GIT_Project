package b.a.a.a;

import java.io.IOException;

public class a extends IOException
{
  private static final long a = 617550366255636674L;

  public a(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.a
 * JD-Core Version:    0.6.0
 */