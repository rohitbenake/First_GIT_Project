package b.a.a.a;

public abstract interface ab
{
  public static final int A = 408;
  public static final int B = 409;
  public static final int C = 410;
  public static final int D = 411;
  public static final int E = 412;
  public static final int F = 413;
  public static final int G = 414;
  public static final int H = 415;
  public static final int I = 416;
  public static final int J = 417;
  public static final int K = 419;
  public static final int L = 420;
  public static final int M = 422;
  public static final int N = 423;
  public static final int O = 424;
  public static final int P = 500;
  public static final int Q = 501;
  public static final int R = 502;
  public static final int S = 503;
  public static final int T = 504;
  public static final int U = 505;
  public static final int V = 507;
  public static final int a = 100;
  public static final int b = 101;
  public static final int c = 102;
  public static final int d = 200;
  public static final int e = 201;
  public static final int f = 202;
  public static final int g = 203;
  public static final int h = 204;
  public static final int i = 205;
  public static final int j = 206;
  public static final int k = 207;
  public static final int l = 300;
  public static final int m = 301;
  public static final int n = 302;
  public static final int o = 303;
  public static final int p = 304;
  public static final int q = 305;
  public static final int r = 307;
  public static final int s = 400;
  public static final int t = 401;
  public static final int u = 402;
  public static final int v = 403;
  public static final int w = 404;
  public static final int x = 405;
  public static final int y = 406;
  public static final int z = 407;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.ab
 * JD-Core Version:    0.6.0
 */