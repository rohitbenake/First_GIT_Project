package b.a.a.a;

import java.io.IOException;

public class ad extends IOException
{
  private static final long a = 2158560246948994524L;

  public ad()
  {
  }

  public ad(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.ad
 * JD-Core Version:    0.6.0
 */