package b.a.a.a;

public class af extends p
{
  private static final long a = 3365359036840171201L;

  public af(String paramString)
  {
    super(paramString);
  }

  public af(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.af
 * JD-Core Version:    0.6.0
 */