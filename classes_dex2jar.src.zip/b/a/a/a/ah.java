package b.a.a.a;

import java.io.IOException;

public class ah extends IOException
{
  private static final long a = -7658940387386078766L;

  public ah(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.ah
 * JD-Core Version:    0.6.0
 */