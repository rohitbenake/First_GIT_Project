package b.a.a.a;

public class ai extends RuntimeException
{
  private static final long a = -7288819855864183578L;

  public ai()
  {
  }

  public ai(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.ai
 * JD-Core Version:    0.6.0
 */