package b.a.a.a;

public class aj extends p
{
  private static final long a = -2143571074341228994L;

  public aj()
  {
  }

  public aj(String paramString)
  {
    super(paramString);
  }

  public aj(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.aj
 * JD-Core Version:    0.6.0
 */