package b.a.a.a;

import b.a.a.a.a.b;
import b.a.a.a.p.a;
import java.io.Serializable;

@b
public class ak
  implements Serializable, Cloneable
{
  private static final long a = 8950662842175091068L;
  protected final String e;
  protected final int f;
  protected final int g;

  public ak(String paramString, int paramInt1, int paramInt2)
  {
    this.e = ((String)a.a(paramString, "Protocol name"));
    this.f = a.b(paramInt1, "Protocol minor version");
    this.g = a.b(paramInt2, "Protocol minor version");
  }

  public ak a(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == this.f) && (paramInt2 == this.g))
      return this;
    return new ak(this.e, paramInt1, paramInt2);
  }

  public final String a()
  {
    return this.e;
  }

  public boolean a(ak paramak)
  {
    return (paramak != null) && (this.e.equals(paramak.e));
  }

  public final int b()
  {
    return this.f;
  }

  public int b(ak paramak)
  {
    a.a(paramak, "Protocol version");
    a.a(this.e.equals(paramak.e), "Versions for different protocols cannot be compared: %s %s", new Object[] { this, paramak });
    int i = b() - paramak.b();
    if (i == 0)
      i = c() - paramak.c();
    return i;
  }

  public final int c()
  {
    return this.g;
  }

  public final boolean c(ak paramak)
  {
    return (a(paramak)) && (b(paramak) >= 0);
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    return super.clone();
  }

  public final boolean d(ak paramak)
  {
    return (a(paramak)) && (b(paramak) <= 0);
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject);
    ak localak;
    do
    {
      return true;
      if (!(paramObject instanceof ak))
        return false;
      localak = (ak)paramObject;
    }
    while ((this.e.equals(localak.e)) && (this.f == localak.f) && (this.g == localak.g));
    return false;
  }

  public final int hashCode()
  {
    return this.e.hashCode() ^ 100000 * this.f ^ this.g;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.e);
    localStringBuilder.append('/');
    localStringBuilder.append(Integer.toString(this.f));
    localStringBuilder.append('.');
    localStringBuilder.append(Integer.toString(this.g));
    return localStringBuilder.toString();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.ak
 * JD-Core Version:    0.6.0
 */