package b.a.a.a;

import java.util.Iterator;

public abstract interface ao extends Iterator<Object>
{
  public abstract String a();

  public abstract boolean hasNext();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.ao
 * JD-Core Version:    0.6.0
 */