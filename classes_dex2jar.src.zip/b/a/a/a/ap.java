package b.a.a.a;

public class ap extends ad
{
  private static final long a = -23506263930279460L;

  public ap(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.ap
 * JD-Core Version:    0.6.0
 */