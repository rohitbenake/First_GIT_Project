package b.a.a.a;

public class aq extends aj
{
  private static final long a = -1348448090193107031L;

  public aq()
  {
  }

  public aq(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.aq
 * JD-Core Version:    0.6.0
 */