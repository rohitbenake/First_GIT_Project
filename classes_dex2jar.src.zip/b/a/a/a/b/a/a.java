package b.a.a.a.b.a;

@Deprecated
public abstract interface a
{
  public static final String A_ = "http.auth.proxy-scheme-pref";
  public static final String w_ = "http.auth.credential-charset";
  public static final String z_ = "http.auth.target-scheme-pref";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.a.a
 * JD-Core Version:    0.6.0
 */