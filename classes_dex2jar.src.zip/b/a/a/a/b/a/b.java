package b.a.a.a.b.a;

import b.a.a.a.m.f;
import b.a.a.a.m.j;

@Deprecated
public class b extends f
{
  public b(j paramj)
  {
    super(paramj);
  }

  public void a(String paramString)
  {
    c.a(this.a, paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.a.b
 * JD-Core Version:    0.6.0
 */