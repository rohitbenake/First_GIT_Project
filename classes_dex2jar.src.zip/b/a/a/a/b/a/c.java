package b.a.a.a.b.a;

import b.a.a.a.a.b;
import b.a.a.a.m.j;
import b.a.a.a.o.f;
import b.a.a.a.p.a;
import java.nio.charset.Charset;

@Deprecated
@b
public final class c
{
  public static String a(j paramj)
  {
    a.a(paramj, "HTTP parameters");
    String str = (String)paramj.a("http.auth.credential-charset");
    if (str == null)
      str = f.u.name();
    return str;
  }

  public static void a(j paramj, String paramString)
  {
    a.a(paramj, "HTTP parameters");
    paramj.a("http.auth.credential-charset", paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.a.c
 * JD-Core Version:    0.6.0
 */