package b.a.a.a.b;

import b.a.a.a.p.a;

@b.a.a.a.a.b
public final class b
{
  private final d a;
  private final n b;

  public b(d paramd, n paramn)
  {
    a.a(paramd, "Auth scheme");
    a.a(paramn, "User credentials");
    this.a = paramd;
    this.b = paramn;
  }

  public d a()
  {
    return this.a;
  }

  public n b()
  {
    return this.b;
  }

  public String toString()
  {
    return this.a.toString();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.b
 * JD-Core Version:    0.6.0
 */