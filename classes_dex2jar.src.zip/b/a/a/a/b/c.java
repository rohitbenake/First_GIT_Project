package b.a.a.a.b;

public enum c
{
  static
  {
    c[] arrayOfc = new c[5];
    arrayOfc[0] = a;
    arrayOfc[1] = b;
    arrayOfc[2] = c;
    arrayOfc[3] = d;
    arrayOfc[4] = e;
    f = arrayOfc;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.c
 * JD-Core Version:    0.6.0
 */