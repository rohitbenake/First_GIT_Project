package b.a.a.a.b;

import b.a.a.a.f;
import b.a.a.a.u;

public abstract interface d
{
  @Deprecated
  public abstract f a(n paramn, u paramu)
    throws j;

  public abstract String a();

  public abstract String a(String paramString);

  public abstract void a(f paramf)
    throws p;

  public abstract String b();

  public abstract boolean c();

  public abstract boolean d();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.d
 * JD-Core Version:    0.6.0
 */