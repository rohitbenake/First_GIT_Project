package b.a.a.a.b;

import b.a.a.a.e.b;
import b.a.a.a.m.j;
import b.a.a.a.p.a;
import b.a.a.a.u;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Deprecated
@b.a.a.a.a.d
public final class g
  implements b<f>
{
  private final ConcurrentHashMap<String, e> a = new ConcurrentHashMap();

  public d a(String paramString, j paramj)
    throws IllegalStateException
  {
    a.a(paramString, "Name");
    e locale = (e)this.a.get(paramString.toLowerCase(Locale.ENGLISH));
    if (locale != null)
      return locale.a(paramj);
    throw new IllegalStateException("Unsupported authentication scheme: " + paramString);
  }

  public List<String> a()
  {
    return new ArrayList(this.a.keySet());
  }

  public void a(String paramString)
  {
    a.a(paramString, "Name");
    this.a.remove(paramString.toLowerCase(Locale.ENGLISH));
  }

  public void a(String paramString, e parame)
  {
    a.a(paramString, "Name");
    a.a(parame, "Authentication scheme factory");
    this.a.put(paramString.toLowerCase(Locale.ENGLISH), parame);
  }

  public void a(Map<String, e> paramMap)
  {
    if (paramMap == null)
      return;
    this.a.clear();
    this.a.putAll(paramMap);
  }

  public f b(String paramString)
  {
    return new f(paramString)
    {
      public d a(b.a.a.a.o.g paramg)
      {
        u localu = (u)paramg.a("http.request");
        return g.this.a(this.a, localu.g());
      }
    };
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.g
 * JD-Core Version:    0.6.0
 */