package b.a.a.a.b;

import b.a.a.a.a.b;
import b.a.a.a.p.a;
import b.a.a.a.p.i;
import b.a.a.a.r;
import java.util.Locale;

@b
public class h
{
  public static final String a = null;
  public static final int b = -1;
  public static final String c = null;
  public static final String d = null;
  public static final h e = new h(a, -1, c, d);
  private final String f;
  private final String g;
  private final String h;
  private final int i;

  public h(h paramh)
  {
    a.a(paramh, "Scope");
    this.h = paramh.a();
    this.i = paramh.b();
    this.g = paramh.c();
    this.f = paramh.d();
  }

  public h(r paramr)
  {
    this(paramr, c, d);
  }

  public h(r paramr, String paramString1, String paramString2)
  {
    this(paramr.a(), paramr.b(), paramString1, paramString2);
  }

  public h(String paramString, int paramInt)
  {
    this(paramString, paramInt, c, d);
  }

  public h(String paramString1, int paramInt, String paramString2)
  {
    this(paramString1, paramInt, paramString2, d);
  }

  public h(String paramString1, int paramInt, String paramString2, String paramString3)
  {
    String str1;
    if (paramString1 == null)
    {
      str1 = a;
      this.h = str1;
      if (paramInt < 0)
        paramInt = -1;
      this.i = paramInt;
      if (paramString2 == null)
        paramString2 = c;
      this.g = paramString2;
      if (paramString3 != null)
        break label72;
    }
    label72: for (String str2 = d; ; str2 = paramString3.toUpperCase(Locale.ENGLISH))
    {
      this.f = str2;
      return;
      str1 = paramString1.toLowerCase(Locale.ENGLISH);
      break;
    }
  }

  public int a(h paramh)
  {
    int j;
    if (i.a(this.f, paramh.f))
    {
      j = 0 + 1;
      if (!i.a(this.g, paramh.g))
        break label110;
      j += 2;
      label36: if (this.i != paramh.i)
        break label132;
      j += 4;
      label50: if (!i.a(this.h, paramh.h))
        break label150;
      j += 8;
    }
    label110: 
    do
    {
      return j;
      String str1 = this.f;
      String str2 = d;
      j = 0;
      if (str1 == str2)
        break;
      String str3 = paramh.f;
      String str4 = d;
      j = 0;
      if (str3 == str4)
        break;
      return -1;
      if ((this.g == c) || (paramh.g == c))
        break label36;
      return -1;
      if ((this.i == -1) || (paramh.i == -1))
        break label50;
      return -1;
    }
    while ((this.h == a) || (paramh.h == a));
    label132: label150: return -1;
  }

  public String a()
  {
    return this.h;
  }

  public int b()
  {
    return this.i;
  }

  public String c()
  {
    return this.g;
  }

  public String d()
  {
    return this.f;
  }

  public boolean equals(Object paramObject)
  {
    int j = 1;
    if (paramObject == null)
      j = 0;
    h localh;
    do
    {
      do
        return j;
      while (paramObject == this);
      if (!(paramObject instanceof h))
        return super.equals(paramObject);
      localh = (h)paramObject;
    }
    while ((i.a(this.h, localh.h)) && (this.i == localh.i) && (i.a(this.g, localh.g)) && (i.a(this.f, localh.f)));
    return false;
  }

  public int hashCode()
  {
    return i.a(i.a(i.a(i.a(17, this.h), this.i), this.g), this.f);
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (this.f != null)
    {
      localStringBuilder.append(this.f.toUpperCase(Locale.ENGLISH));
      localStringBuilder.append(' ');
    }
    if (this.g != null)
    {
      localStringBuilder.append('\'');
      localStringBuilder.append(this.g);
      localStringBuilder.append('\'');
    }
    while (true)
    {
      if (this.h != null)
      {
        localStringBuilder.append('@');
        localStringBuilder.append(this.h);
        if (this.i >= 0)
        {
          localStringBuilder.append(':');
          localStringBuilder.append(this.i);
        }
      }
      return localStringBuilder.toString();
      localStringBuilder.append("<any realm>");
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.h
 * JD-Core Version:    0.6.0
 */