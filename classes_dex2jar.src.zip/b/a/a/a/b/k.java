package b.a.a.a.b;

import b.a.a.a.a.b;
import b.a.a.a.p.a;
import b.a.a.a.p.i;
import java.io.Serializable;
import java.security.Principal;

@b
public final class k
  implements Serializable, Principal
{
  private static final long a = -2266305184969850467L;
  private final String b;

  public k(String paramString)
  {
    a.a(paramString, "User name");
    this.b = paramString;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    k localk;
    do
    {
      return true;
      if (!(paramObject instanceof k))
        break;
      localk = (k)paramObject;
    }
    while (i.a(this.b, localk.b));
    return false;
  }

  public String getName()
  {
    return this.b;
  }

  public int hashCode()
  {
    return i.a(17, this.b);
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[principal: ");
    localStringBuilder.append(this.b);
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.k
 * JD-Core Version:    0.6.0
 */