package b.a.a.a.b;

public enum l
{
  static
  {
    l[] arrayOfl = new l[2];
    arrayOfl[0] = a;
    arrayOfl[1] = b;
    c = arrayOfl;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.l
 * JD-Core Version:    0.6.0
 */