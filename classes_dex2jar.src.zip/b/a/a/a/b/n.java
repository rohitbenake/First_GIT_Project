package b.a.a.a.b;

import java.security.Principal;

public abstract interface n
{
  public abstract Principal a();

  public abstract String b();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.n
 * JD-Core Version:    0.6.0
 */