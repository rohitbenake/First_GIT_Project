package b.a.a.a.b;

import b.a.a.a.a.b;

@b
public class o extends j
{
  private static final long a = -4834003835215460648L;

  public o()
  {
  }

  public o(String paramString)
  {
    super(paramString);
  }

  public o(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.o
 * JD-Core Version:    0.6.0
 */