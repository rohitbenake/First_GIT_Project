package b.a.a.a.b;

import b.a.a.a.a.b;
import b.a.a.a.p.a;
import b.a.a.a.p.i;
import java.io.Serializable;
import java.security.Principal;
import java.util.Locale;

@b
public class q
  implements n, Serializable
{
  private static final long a = -7385699315228907265L;
  private final r b;
  private final String c;
  private final String d;

  public q(String paramString)
  {
    a.a(paramString, "Username:password string");
    int i = paramString.indexOf(':');
    String str;
    int j;
    if (i >= 0)
    {
      str = paramString.substring(0, i);
      this.c = paramString.substring(i + 1);
      j = str.indexOf('/');
      if (j < 0)
        break label106;
    }
    label106: for (this.b = new r(str.substring(0, j).toUpperCase(Locale.ENGLISH), str.substring(j + 1)); ; this.b = new r(null, str.substring(j + 1)))
    {
      this.d = null;
      return;
      str = paramString;
      this.c = null;
      break;
    }
  }

  public q(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    a.a(paramString1, "User name");
    this.b = new r(paramString4, paramString1);
    this.c = paramString2;
    if (paramString3 != null)
    {
      this.d = paramString3.toUpperCase(Locale.ENGLISH);
      return;
    }
    this.d = null;
  }

  public Principal a()
  {
    return this.b;
  }

  public String b()
  {
    return this.c;
  }

  public String c()
  {
    return this.b.b();
  }

  public String d()
  {
    return this.b.a();
  }

  public String e()
  {
    return this.d;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    q localq;
    do
    {
      return true;
      if (!(paramObject instanceof q))
        break;
      localq = (q)paramObject;
    }
    while ((i.a(this.b, localq.b)) && (i.a(this.d, localq.d)));
    return false;
  }

  public int hashCode()
  {
    return i.a(i.a(17, this.b), this.d);
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[principal: ");
    localStringBuilder.append(this.b);
    localStringBuilder.append("][workstation: ");
    localStringBuilder.append(this.d);
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.q
 * JD-Core Version:    0.6.0
 */