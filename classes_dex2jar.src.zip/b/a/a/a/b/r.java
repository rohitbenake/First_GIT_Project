package b.a.a.a.b;

import b.a.a.a.a.b;
import b.a.a.a.p.a;
import b.a.a.a.p.i;
import java.io.Serializable;
import java.security.Principal;
import java.util.Locale;

@b
public class r
  implements Serializable, Principal
{
  private static final long a = -6870169797924406894L;
  private final String b;
  private final String c;
  private final String d;

  public r(String paramString1, String paramString2)
  {
    a.a(paramString2, "User name");
    this.b = paramString2;
    if (paramString1 != null);
    for (this.c = paramString1.toUpperCase(Locale.ENGLISH); (this.c != null) && (this.c.length() > 0); this.c = null)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(this.c);
      localStringBuilder.append('\\');
      localStringBuilder.append(this.b);
      this.d = localStringBuilder.toString();
      return;
    }
    this.d = this.b;
  }

  public String a()
  {
    return this.c;
  }

  public String b()
  {
    return this.b;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    r localr;
    do
    {
      return true;
      if (!(paramObject instanceof r))
        break;
      localr = (r)paramObject;
    }
    while ((i.a(this.b, localr.b)) && (i.a(this.c, localr.c)));
    return false;
  }

  public String getName()
  {
    return this.d;
  }

  public int hashCode()
  {
    return i.a(i.a(17, this.b), this.c);
  }

  public String toString()
  {
    return this.d;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.r
 * JD-Core Version:    0.6.0
 */