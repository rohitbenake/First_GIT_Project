package b.a.a.a.b;

import b.a.a.a.a.b;
import b.a.a.a.p.a;
import b.a.a.a.p.i;
import java.io.Serializable;
import java.security.Principal;

@b
public class s
  implements n, Serializable
{
  private static final long a = 243343858802739403L;
  private final k b;
  private final String c;

  public s(String paramString)
  {
    a.a(paramString, "Username:password string");
    int i = paramString.indexOf(':');
    if (i >= 0)
    {
      this.b = new k(paramString.substring(0, i));
      this.c = paramString.substring(i + 1);
      return;
    }
    this.b = new k(paramString);
    this.c = null;
  }

  public s(String paramString1, String paramString2)
  {
    a.a(paramString1, "Username");
    this.b = new k(paramString1);
    this.c = paramString2;
  }

  public Principal a()
  {
    return this.b;
  }

  public String b()
  {
    return this.c;
  }

  public String c()
  {
    return this.b.getName();
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    s locals;
    do
    {
      return true;
      if (!(paramObject instanceof s))
        break;
      locals = (s)paramObject;
    }
    while (i.a(this.b, locals.b));
    return false;
  }

  public int hashCode()
  {
    return this.b.hashCode();
  }

  public String toString()
  {
    return this.b.toString();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.b.s
 * JD-Core Version:    0.6.0
 */