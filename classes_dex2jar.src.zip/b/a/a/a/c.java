package b.a.a.a;

import java.nio.charset.Charset;

public final class c
{
  public static final int a = 13;
  public static final int b = 10;
  public static final int c = 32;
  public static final int d = 9;
  public static final Charset e = Charset.forName("UTF-8");
  public static final Charset f = Charset.forName("US-ASCII");
  public static final Charset g = Charset.forName("ISO-8859-1");
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c
 * JD-Core Version:    0.6.0
 */