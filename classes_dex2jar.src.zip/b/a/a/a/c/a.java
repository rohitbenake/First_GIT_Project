package b.a.a.a.c;

import b.a.a.a.b.d;
import b.a.a.a.r;

public abstract interface a
{
  public abstract d a(r paramr);

  public abstract void a();

  public abstract void a(r paramr, d paramd);

  public abstract void b(r paramr);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a
 * JD-Core Version:    0.6.0
 */