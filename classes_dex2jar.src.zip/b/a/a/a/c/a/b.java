package b.a.a.a.c.a;

@b.a.a.a.a.b
public class b
{
  public static final String A = "max-stale";
  public static final String B = "min-fresh";
  public static final String C = "must-revalidate";
  public static final String D = "proxy-revalidate";
  public static final String E = "stale-if-error";
  public static final String F = "stale-while-revalidate";
  public static final String G = "Warning";
  public static final String H = "Range";
  public static final String I = "Content-Range";
  public static final String J = "WWW-Authenticate";
  public static final String K = "Proxy-Authenticate";
  public static final String L = "Authorization";
  public static final String a = "GET";
  public static final String b = "HEAD";
  public static final String c = "OPTIONS";
  public static final String d = "PUT";
  public static final String e = "DELETE";
  public static final String f = "TRACE";
  public static final String g = "Last-Modified";
  public static final String h = "If-Match";
  public static final String i = "If-Range";
  public static final String j = "If-Unmodified-Since";
  public static final String k = "If-Modified-Since";
  public static final String l = "If-None-Match";
  public static final String m = "Pragma";
  public static final String n = "Max-Forwards";
  public static final String o = "ETag";
  public static final String p = "Expires";
  public static final String q = "Age";
  public static final String r = "Vary";
  public static final String s = "Allow";
  public static final String t = "Via";
  public static final String u = "public";
  public static final String v = "private";
  public static final String w = "Cache-Control";
  public static final String x = "no-store";
  public static final String y = "no-cache";
  public static final String z = "max-age";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.b
 * JD-Core Version:    0.6.0
 */