package b.a.a.a.c.a;

import b.a.a.a.o.g;

@b.a.a.a.a.c
public class c extends b.a.a.a.c.f.c
{
  public static final String a = "http.cache.response.status";

  public c()
  {
  }

  public c(g paramg)
  {
    super(paramg);
  }

  public static c a()
  {
    return new c(new b.a.a.a.o.a());
  }

  public static c a(g paramg)
  {
    if ((paramg instanceof c))
      return (c)paramg;
    return new c(paramg);
  }

  public a b()
  {
    return (a)a("http.cache.response.status", a.class);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.c
 * JD-Core Version:    0.6.0
 */