package b.a.a.a.c.a;

import b.a.a.a.ak;
import b.a.a.a.an;
import b.a.a.a.f;
import b.a.a.a.l.s;
import b.a.a.a.p.a;
import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@b.a.a.a.a.b
public class d
  implements Serializable
{
  private static final long a = -6300496422359477413L;
  private final Date b;
  private final Date c;
  private final an d;
  private final s e;
  private final l f;
  private final Map<String, String> g;
  private final Date h;

  public d(Date paramDate1, Date paramDate2, an paraman, f[] paramArrayOff, l paraml)
  {
    this(paramDate1, paramDate2, paraman, paramArrayOff, paraml, new HashMap());
  }

  public d(Date paramDate1, Date paramDate2, an paraman, f[] paramArrayOff, l paraml, Map<String, String> paramMap)
  {
    a.a(paramDate1, "Request date");
    a.a(paramDate2, "Response date");
    a.a(paraman, "Status line");
    a.a(paramArrayOff, "Response headers");
    this.b = paramDate1;
    this.c = paramDate2;
    this.d = paraman;
    this.e = new s();
    this.e.a(paramArrayOff);
    this.f = paraml;
    if (paramMap != null);
    for (HashMap localHashMap = new HashMap(paramMap); ; localHashMap = null)
    {
      this.g = localHashMap;
      this.h = l();
      return;
    }
  }

  private Date l()
  {
    f localf = a("Date");
    if (localf == null)
      return null;
    return b.a.a.a.c.g.b.a(localf.d());
  }

  public an a()
  {
    return this.d;
  }

  public f a(String paramString)
  {
    return this.e.c(paramString);
  }

  public ak b()
  {
    return this.d.a();
  }

  public f[] b(String paramString)
  {
    return this.e.b(paramString);
  }

  public String c()
  {
    return this.d.c();
  }

  public int d()
  {
    return this.d.b();
  }

  public Date e()
  {
    return this.b;
  }

  public Date f()
  {
    return this.c;
  }

  public f[] g()
  {
    return this.e.b();
  }

  public Date h()
  {
    return this.h;
  }

  public l i()
  {
    return this.f;
  }

  public boolean j()
  {
    return a("Vary") != null;
  }

  public Map<String, String> k()
  {
    return Collections.unmodifiableMap(this.g);
  }

  public String toString()
  {
    return "[request date=" + this.b + "; response date=" + this.c + "; statusLine=" + this.d + "]";
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.d
 * JD-Core Version:    0.6.0
 */