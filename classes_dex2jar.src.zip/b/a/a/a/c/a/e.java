package b.a.a.a.c.a;

import java.io.IOException;

public class e extends IOException
{
  private static final long a = 9219188365878433519L;

  public e(String paramString)
  {
  }

  public e(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    initCause(paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.e
 * JD-Core Version:    0.6.0
 */