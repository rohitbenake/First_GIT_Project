package b.a.a.a.c.a;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract interface f
{
  public abstract d a(InputStream paramInputStream)
    throws IOException;

  public abstract void a(d paramd, OutputStream paramOutputStream)
    throws IOException;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.f
 * JD-Core Version:    0.6.0
 */