package b.a.a.a.c.a;

import java.io.IOException;

public abstract interface h
{
  public abstract d a(String paramString)
    throws IOException;

  public abstract void a(String paramString, d paramd)
    throws IOException;

  public abstract void a(String paramString, i parami)
    throws IOException, j;

  public abstract void b(String paramString)
    throws IOException;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.h
 * JD-Core Version:    0.6.0
 */