package b.a.a.a.c.a;

public class j extends Exception
{
  private static final long a = 823573584868632876L;

  public j(String paramString)
  {
    super(paramString);
  }

  public j(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    initCause(paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.j
 * JD-Core Version:    0.6.0
 */