package b.a.a.a.c.a;

import b.a.a.a.a.c;

@c
public class k
{
  private final long a;
  private boolean b;

  public k(long paramLong)
  {
    this.a = paramLong;
    this.b = false;
  }

  public long a()
  {
    return this.a;
  }

  public void b()
  {
    this.b = true;
  }

  public boolean c()
  {
    return this.b;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.a.k
 * JD-Core Version:    0.6.0
 */