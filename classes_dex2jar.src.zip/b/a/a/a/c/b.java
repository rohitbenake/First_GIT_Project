package b.a.a.a.c;

import b.a.a.a.b.d;
import b.a.a.a.b.j;
import b.a.a.a.b.p;
import b.a.a.a.f;
import b.a.a.a.o.g;
import b.a.a.a.x;
import java.util.Map;

@Deprecated
public abstract interface b
{
  public abstract d a(Map<String, f> paramMap, x paramx, g paramg)
    throws j;

  public abstract boolean a(x paramx, g paramg);

  public abstract Map<String, f> b(x paramx, g paramg)
    throws p;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.b
 * JD-Core Version:    0.6.0
 */