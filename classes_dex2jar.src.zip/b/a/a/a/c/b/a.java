package b.a.a.a.c.b;

import b.a.a.a.a.b;

@b
public final class a
{
  public static final String a = "Basic";
  public static final String b = "Digest";
  public static final String c = "NTLM";
  public static final String d = "negotiate";
  public static final String e = "Kerberos";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.b.a
 * JD-Core Version:    0.6.0
 */