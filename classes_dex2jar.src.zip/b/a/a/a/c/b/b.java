package b.a.a.a.c.b;

@b.a.a.a.a.b
public final class b
{
  public static final String a = "compatibility";
  public static final String b = "netscape";
  public static final String c = "standard";
  public static final String d = "best-match";
  public static final String e = "ignoreCookies";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.b.b
 * JD-Core Version:    0.6.0
 */