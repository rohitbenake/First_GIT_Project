package b.a.a.a.c;

import b.a.a.a.b.b;
import b.a.a.a.b.d;
import b.a.a.a.b.p;
import b.a.a.a.f;
import b.a.a.a.o.g;
import b.a.a.a.r;
import b.a.a.a.x;
import java.util.Map;
import java.util.Queue;

public abstract interface c
{
  public abstract Queue<b> a(Map<String, f> paramMap, r paramr, x paramx, g paramg)
    throws p;

  public abstract void a(r paramr, d paramd, g paramg);

  public abstract boolean a(r paramr, x paramx, g paramg);

  public abstract Map<String, f> b(r paramr, x paramx, g paramg)
    throws p;

  public abstract void b(r paramr, d paramd, g paramg);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.c
 * JD-Core Version:    0.6.0
 */