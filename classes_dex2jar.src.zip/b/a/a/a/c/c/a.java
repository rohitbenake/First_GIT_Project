package b.a.a.a.c.c;

import b.a.a.a.h.j;
import b.a.a.a.n;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

abstract class a extends j
{
  private static final int a = 2048;
  private InputStream b;

  public a(n paramn)
  {
    super(paramn);
  }

  private InputStream i()
    throws IOException
  {
    return new g(this.d.a(), this);
  }

  public InputStream a()
    throws IOException
  {
    if (this.d.f())
    {
      if (this.b == null)
        this.b = i();
      return this.b;
    }
    return i();
  }

  abstract InputStream a(InputStream paramInputStream)
    throws IOException;

  public void a(OutputStream paramOutputStream)
    throws IOException
  {
    b.a.a.a.p.a.a(paramOutputStream, "Output stream");
    InputStream localInputStream = a();
    try
    {
      byte[] arrayOfByte = new byte[2048];
      while (true)
      {
        int i = localInputStream.read(arrayOfByte);
        if (i == -1)
          break;
        paramOutputStream.write(arrayOfByte, 0, i);
      }
    }
    finally
    {
      localInputStream.close();
    }
    localInputStream.close();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.c.a
 * JD-Core Version:    0.6.0
 */