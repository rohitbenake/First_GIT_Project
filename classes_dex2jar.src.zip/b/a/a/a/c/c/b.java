package b.a.a.a.c.c;

import b.a.a.a.f;
import b.a.a.a.n;
import java.io.IOException;
import java.io.InputStream;

public class b extends a
{
  public b(n paramn)
  {
    super(paramn);
  }

  InputStream a(InputStream paramInputStream)
    throws IOException
  {
    return new c(paramInputStream);
  }

  public long b()
  {
    return -1L;
  }

  public f g()
  {
    return null;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.c.b
 * JD-Core Version:    0.6.0
 */