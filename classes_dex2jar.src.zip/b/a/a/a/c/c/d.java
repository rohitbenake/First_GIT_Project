package b.a.a.a.c.c;

import b.a.a.a.a.c;
import b.a.a.a.ag;
import b.a.a.a.h.a;
import b.a.a.a.h.b;
import b.a.a.a.h.g;
import b.a.a.a.h.i;
import b.a.a.a.h.k;
import b.a.a.a.h.l;
import b.a.a.a.h.m;
import b.a.a.a.n;
import java.io.File;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;

@c
public class d
{
  private String a;
  private byte[] b;
  private InputStream c;
  private List<ag> d;
  private Serializable e;
  private File f;
  private g g;
  private String h;
  private boolean i;
  private boolean j;

  public static d a()
  {
    return new d();
  }

  private g b(g paramg)
  {
    if (this.g != null)
      paramg = this.g;
    return paramg;
  }

  private void o()
  {
    this.a = null;
    this.b = null;
    this.c = null;
    this.d = null;
    this.e = null;
    this.f = null;
  }

  public d a(g paramg)
  {
    this.g = paramg;
    return this;
  }

  public d a(File paramFile)
  {
    o();
    this.f = paramFile;
    return this;
  }

  public d a(InputStream paramInputStream)
  {
    o();
    this.c = paramInputStream;
    return this;
  }

  public d a(Serializable paramSerializable)
  {
    o();
    this.e = paramSerializable;
    return this;
  }

  public d a(String paramString)
  {
    o();
    this.a = paramString;
    return this;
  }

  public d a(List<ag> paramList)
  {
    o();
    this.d = paramList;
    return this;
  }

  public d a(byte[] paramArrayOfByte)
  {
    o();
    this.b = paramArrayOfByte;
    return this;
  }

  public d a(ag[] paramArrayOfag)
  {
    return a(Arrays.asList(paramArrayOfag));
  }

  public d b(String paramString)
  {
    this.h = paramString;
    return this;
  }

  public String b()
  {
    return this.a;
  }

  public byte[] c()
  {
    return this.b;
  }

  public InputStream d()
  {
    return this.c;
  }

  public List<ag> e()
  {
    return this.d;
  }

  public Serializable f()
  {
    return this.e;
  }

  public File g()
  {
    return this.f;
  }

  public g h()
  {
    return this.g;
  }

  public String i()
  {
    return this.h;
  }

  public boolean j()
  {
    return this.i;
  }

  public d k()
  {
    this.i = true;
    return this;
  }

  public boolean l()
  {
    return this.j;
  }

  public d m()
  {
    this.j = true;
    return this;
  }

  public n n()
  {
    Object localObject;
    if (this.a != null)
      localObject = new m(this.a, b(g.m));
    while (true)
    {
      if ((((a)localObject).h() != null) && (this.g != null))
        ((a)localObject).a(this.g.toString());
      ((a)localObject).b(this.h);
      ((a)localObject).a(this.i);
      if (this.j)
        localObject = new e((n)localObject);
      return localObject;
      if (this.b != null)
      {
        localObject = new b.a.a.a.h.d(this.b, b(g.n));
        continue;
      }
      if (this.c != null)
      {
        localObject = new k(this.c, 1L, b(g.n));
        continue;
      }
      if (this.d != null)
      {
        List localList = this.d;
        if (this.g != null);
        for (Charset localCharset = this.g.b(); ; localCharset = null)
        {
          localObject = new h(localList, localCharset);
          break;
        }
      }
      if (this.e != null)
      {
        localObject = new l(this.e);
        ((a)localObject).a(g.n.toString());
        continue;
      }
      if (this.f != null)
      {
        localObject = new i(this.f, b(g.n));
        continue;
      }
      localObject = new b();
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.c.d
 * JD-Core Version:    0.6.0
 */