package b.a.a.a.c.c;

import b.a.a.a.f;
import b.a.a.a.h.j;
import b.a.a.a.l.b;
import b.a.a.a.n;
import b.a.a.a.p.a;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

public class e extends j
{
  private static final String a = "gzip";

  public e(n paramn)
  {
    super(paramn);
  }

  public InputStream a()
    throws IOException
  {
    throw new UnsupportedOperationException();
  }

  public void a(OutputStream paramOutputStream)
    throws IOException
  {
    a.a(paramOutputStream, "Output stream");
    GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(paramOutputStream);
    this.d.a(localGZIPOutputStream);
    localGZIPOutputStream.close();
  }

  public long b()
  {
    return -1L;
  }

  public boolean e()
  {
    return true;
  }

  public f g()
  {
    return new b("Content-Encoding", "gzip");
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.c.e
 * JD-Core Version:    0.6.0
 */