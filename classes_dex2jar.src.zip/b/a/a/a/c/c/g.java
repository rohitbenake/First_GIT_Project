package b.a.a.a.c.c;

import b.a.a.a.a.c;
import java.io.IOException;
import java.io.InputStream;

@c
class g extends InputStream
{
  private final InputStream a;
  private final a b;
  private InputStream c;

  public g(InputStream paramInputStream, a parama)
  {
    this.a = paramInputStream;
    this.b = parama;
  }

  private void a()
    throws IOException
  {
    if (this.c == null)
      this.c = this.b.a(this.a);
  }

  public int available()
    throws IOException
  {
    a();
    return this.c.available();
  }

  public void close()
    throws IOException
  {
    try
    {
      if (this.c != null)
        this.c.close();
      return;
    }
    finally
    {
      this.a.close();
    }
    throw localObject;
  }

  public boolean markSupported()
  {
    return false;
  }

  public int read()
    throws IOException
  {
    a();
    return this.c.read();
  }

  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    a();
    return this.c.read(paramArrayOfByte);
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    a();
    return this.c.read(paramArrayOfByte, paramInt1, paramInt2);
  }

  public long skip(long paramLong)
    throws IOException
  {
    a();
    return this.c.skip(paramLong);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.c.g
 * JD-Core Version:    0.6.0
 */