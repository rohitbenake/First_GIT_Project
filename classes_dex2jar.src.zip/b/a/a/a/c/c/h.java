package b.a.a.a.c.c;

import b.a.a.a.a.c;
import b.a.a.a.ag;
import b.a.a.a.h.m;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.List;

@c
public class h extends m
{
  public h(Iterable<? extends ag> paramIterable)
  {
    this(paramIterable, null);
  }

  public h(Iterable<? extends ag> paramIterable, Charset paramCharset)
  {
  }

  public h(List<? extends ag> paramList)
    throws UnsupportedEncodingException
  {
    this(paramList, (Charset)null);
  }

  public h(List<? extends ag> paramList, String paramString)
    throws UnsupportedEncodingException
  {
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.c.h
 * JD-Core Version:    0.6.0
 */