package b.a.a.a.c.d;

import b.a.a.a.f.f;
import b.a.a.a.f.j;
import java.io.IOException;

@Deprecated
public abstract interface a
{
  public abstract void a(f paramf)
    throws IOException;

  public abstract void a(j paramj)
    throws IOException;

  public abstract void e();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.a
 * JD-Core Version:    0.6.0
 */