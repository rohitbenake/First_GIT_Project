package b.a.a.a.c.d;

import b.a.a.a.f.f;
import b.a.a.a.l.s;
import b.a.a.a.u;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public abstract class b extends b.a.a.a.l.a
  implements a, g, u, Cloneable
{
  private final AtomicBoolean a = new AtomicBoolean(false);
  private final AtomicReference<b.a.a.a.d.b> d = new AtomicReference(null);

  public void a(b.a.a.a.d.b paramb)
  {
    if (!this.a.get())
      this.d.set(paramb);
  }

  @Deprecated
  public void a(f paramf)
  {
    a(new b.a.a.a.d.b(paramf)
    {
      public boolean a()
      {
        this.a.a();
        return true;
      }
    });
  }

  @Deprecated
  public void a(b.a.a.a.f.j paramj)
  {
    a(new b.a.a.a.d.b(paramj)
    {
      public boolean a()
      {
        try
        {
          this.a.j();
          return true;
        }
        catch (IOException localIOException)
        {
        }
        return false;
      }
    });
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    b localb = (b)super.clone();
    localb.b = ((s)b.a.a.a.c.g.a.a(this.b));
    localb.c = ((b.a.a.a.m.j)b.a.a.a.c.g.a.a(this.c));
    return localb;
  }

  public void e()
  {
    if (this.a.compareAndSet(false, true))
    {
      b.a.a.a.d.b localb = (b.a.a.a.d.b)this.d.getAndSet(null);
      if (localb != null)
        localb.a();
    }
  }

  public boolean i()
  {
    return this.a.get();
  }

  public void j()
  {
    this.d.set(null);
  }

  public void k()
  {
    b.a.a.a.d.b localb = (b.a.a.a.d.b)this.d.getAndSet(null);
    if (localb != null)
      localb.a();
    this.a.set(false);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.b
 * JD-Core Version:    0.6.0
 */