package b.a.a.a.c.d;

import b.a.a.a.c.b.c;

public abstract interface d
{
  public abstract c b_();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.d
 * JD-Core Version:    0.6.0
 */