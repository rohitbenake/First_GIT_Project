package b.a.a.a.c.d;

import b.a.a.a.a.c;
import b.a.a.a.c.g.a;
import b.a.a.a.o;

@c
public abstract class f extends n
  implements o
{
  private b.a.a.a.n a;

  public void a(b.a.a.a.n paramn)
  {
    this.a = paramn;
  }

  public boolean b()
  {
    b.a.a.a.f localf = c("Expect");
    return (localf != null) && ("100-continue".equalsIgnoreCase(localf.d()));
  }

  public b.a.a.a.n c()
  {
    return this.a;
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    f localf = (f)super.clone();
    if (this.a != null)
      localf.a = ((b.a.a.a.n)a.a(this.a));
    return localf;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.f
 * JD-Core Version:    0.6.0
 */