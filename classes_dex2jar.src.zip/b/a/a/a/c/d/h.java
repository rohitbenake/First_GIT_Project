package b.a.a.a.c.d;

import b.a.a.a.a.c;
import java.net.URI;

@c
public class h extends n
{
  public static final String a = "GET";

  public h()
  {
  }

  public h(String paramString)
  {
    a(URI.create(paramString));
  }

  public h(URI paramURI)
  {
    a(paramURI);
  }

  public String a()
  {
    return "GET";
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.h
 * JD-Core Version:    0.6.0
 */