package b.a.a.a.c.d;

import b.a.a.a.a.c;
import java.net.URI;

@c
public class i extends n
{
  public static final String a = "HEAD";

  public i()
  {
  }

  public i(String paramString)
  {
    a(URI.create(paramString));
  }

  public i(URI paramURI)
  {
    a(paramURI);
  }

  public String a()
  {
    return "HEAD";
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.i
 * JD-Core Version:    0.6.0
 */