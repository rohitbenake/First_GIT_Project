package b.a.a.a.c.d;

import b.a.a.a.a.c;
import b.a.a.a.f;
import b.a.a.a.g;
import b.a.a.a.i;
import b.a.a.a.p.a;
import b.a.a.a.x;
import java.net.URI;
import java.util.HashSet;
import java.util.Set;

@c
public class j extends n
{
  public static final String a = "OPTIONS";

  public j()
  {
  }

  public j(String paramString)
  {
    a(URI.create(paramString));
  }

  public j(URI paramURI)
  {
    a(paramURI);
  }

  public String a()
  {
    return "OPTIONS";
  }

  public Set<String> a(x paramx)
  {
    a.a(paramx, "HTTP response");
    i locali = paramx.f("Allow");
    HashSet localHashSet = new HashSet();
    while (locali.hasNext())
    {
      g[] arrayOfg = locali.a().e();
      int i = arrayOfg.length;
      for (int j = 0; j < i; j++)
        localHashSet.add(arrayOfg[j].a());
    }
    return localHashSet;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.j
 * JD-Core Version:    0.6.0
 */