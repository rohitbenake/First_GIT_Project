package b.a.a.a.c.d;

import b.a.a.a.a.c;
import java.net.URI;

@c
public class m extends f
{
  public static final String a = "PUT";

  public m()
  {
  }

  public m(String paramString)
  {
    a(URI.create(paramString));
  }

  public m(URI paramURI)
  {
    a(paramURI);
  }

  public String a()
  {
    return "PUT";
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.m
 * JD-Core Version:    0.6.0
 */