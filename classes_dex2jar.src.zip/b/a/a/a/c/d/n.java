package b.a.a.a.c.d;

import b.a.a.a.ak;
import b.a.a.a.am;
import b.a.a.a.l.o;
import b.a.a.a.m.m;
import java.net.URI;

@b.a.a.a.a.c
public abstract class n extends b
  implements d, q
{
  private ak a;
  private URI d;
  private b.a.a.a.c.b.c e;

  public abstract String a();

  public void a(ak paramak)
  {
    this.a = paramak;
  }

  public void a(b.a.a.a.c.b.c paramc)
  {
    this.e = paramc;
  }

  public void a(URI paramURI)
  {
    this.d = paramURI;
  }

  public b.a.a.a.c.b.c b_()
  {
    return this.e;
  }

  public ak d()
  {
    if (this.a != null)
      return this.a;
    return m.c(g());
  }

  public am h()
  {
    String str1 = a();
    ak localak = d();
    URI localURI = l();
    String str2 = null;
    if (localURI != null)
      str2 = localURI.toASCIIString();
    if ((str2 == null) || (str2.length() == 0))
      str2 = "/";
    return new o(str1, str2, localak);
  }

  public URI l()
  {
    return this.d;
  }

  public void m()
  {
  }

  public void n()
  {
    k();
  }

  public String toString()
  {
    return a() + " " + l() + " " + d();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.n
 * JD-Core Version:    0.6.0
 */