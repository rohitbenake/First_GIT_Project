package b.a.a.a.c.d;

import b.a.a.a.a.c;
import b.a.a.a.ak;
import b.a.a.a.am;
import b.a.a.a.f;
import b.a.a.a.l.a;
import b.a.a.a.m.j;
import b.a.a.a.n;
import b.a.a.a.u;
import java.net.URI;

@c
public class o extends a
  implements q
{
  private final u a;
  private final String d;
  private ak e;
  private URI f;

  private o(u paramu)
  {
    this.a = paramu;
    this.e = this.a.h().b();
    this.d = this.a.h().a();
    if ((paramu instanceof q));
    for (this.f = ((q)paramu).l(); ; this.f = null)
    {
      a(paramu.c_());
      return;
    }
  }

  public static o a(u paramu)
  {
    if (paramu == null)
      return null;
    if ((paramu instanceof b.a.a.a.o))
      return new a((b.a.a.a.o)paramu);
    return new o(paramu);
  }

  public String a()
  {
    return this.d;
  }

  public void a(ak paramak)
  {
    this.e = paramak;
  }

  public void a(URI paramURI)
  {
    this.f = paramURI;
  }

  public ak d()
  {
    if (this.e != null)
      return this.e;
    return this.a.d();
  }

  public void e()
    throws UnsupportedOperationException
  {
    throw new UnsupportedOperationException();
  }

  @Deprecated
  public j g()
  {
    if (this.c == null)
      this.c = this.a.g().e();
    return this.c;
  }

  public am h()
  {
    if (this.f != null);
    for (String str = this.f.toASCIIString(); ; str = this.a.h().c())
    {
      if ((str == null) || (str.length() == 0))
        str = "/";
      return new b.a.a.a.l.o(this.d, str, d());
    }
  }

  public boolean i()
  {
    return false;
  }

  public u j()
  {
    return this.a;
  }

  public URI l()
  {
    return this.f;
  }

  public String toString()
  {
    return h() + " " + this.b;
  }

  static class a extends o
    implements b.a.a.a.o
  {
    private n a;

    public a(b.a.a.a.o paramo)
    {
      super(null);
      this.a = paramo.c();
    }

    public void a(n paramn)
    {
      this.a = paramn;
    }

    public boolean b()
    {
      f localf = c("Expect");
      return (localf != null) && ("100-continue".equalsIgnoreCase(localf.d()));
    }

    public n c()
    {
      return this.a;
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.o
 * JD-Core Version:    0.6.0
 */