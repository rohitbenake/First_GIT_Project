package b.a.a.a.c.d;

import b.a.a.a.u;
import java.net.URI;

public abstract interface q extends u
{
  public abstract String a();

  public abstract void e()
    throws UnsupportedOperationException;

  public abstract boolean i();

  public abstract URI l();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.q
 * JD-Core Version:    0.6.0
 */