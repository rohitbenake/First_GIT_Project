package b.a.a.a.c.d;

import b.a.a.a.ag;
import b.a.a.a.ak;
import b.a.a.a.am;
import b.a.a.a.i;
import b.a.a.a.l.b;
import b.a.a.a.l.s;
import b.a.a.a.o;
import b.a.a.a.p.a;
import b.a.a.a.u;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@b.a.a.a.a.c
public class r
{
  private String a;
  private ak b;
  private URI c;
  private s d;
  private b.a.a.a.n e;
  private LinkedList<ag> f;
  private b.a.a.a.c.b.c g;

  r()
  {
    this(null);
  }

  r(String paramString)
  {
    this.a = paramString;
  }

  public static r a()
  {
    return new r("GET");
  }

  public static r a(u paramu)
  {
    a.a(paramu, "HTTP request");
    return new r().b(paramu);
  }

  public static r a(String paramString)
  {
    a.b(paramString, "HTTP method");
    return new r(paramString);
  }

  public static r b()
  {
    return new r("HEAD");
  }

  private r b(u paramu)
  {
    if (paramu == null)
      return this;
    this.a = paramu.h().a();
    this.b = paramu.h().b();
    if ((paramu instanceof q))
    {
      this.c = ((q)paramu).l();
      if (this.d == null)
        this.d = new s();
      this.d.a();
      this.d.a(paramu.c_());
      if (!(paramu instanceof o))
        break label162;
      this.e = ((o)paramu).c();
      label114: if (!(paramu instanceof d))
        break label170;
    }
    label162: label170: for (this.g = ((d)paramu).b_(); ; this.g = null)
    {
      this.f = null;
      return this;
      this.c = URI.create(paramu.h().c());
      break;
      this.e = null;
      break label114;
    }
  }

  public static r c()
  {
    return new r("POST");
  }

  public static r d()
  {
    return new r("PUT");
  }

  public static r e()
  {
    return new r("DELETE");
  }

  public static r f()
  {
    return new r("TRACE");
  }

  public static r g()
  {
    return new r("OPTIONS");
  }

  public r a(ag paramag)
  {
    a.a(paramag, "Name value pair");
    if (this.f == null)
      this.f = new LinkedList();
    this.f.add(paramag);
    return this;
  }

  public r a(ak paramak)
  {
    this.b = paramak;
    return this;
  }

  public r a(b.a.a.a.c.b.c paramc)
  {
    this.g = paramc;
    return this;
  }

  public r a(b.a.a.a.f paramf)
  {
    if (this.d == null)
      this.d = new s();
    this.d.a(paramf);
    return this;
  }

  public r a(b.a.a.a.n paramn)
  {
    this.e = paramn;
    return this;
  }

  public r a(String paramString1, String paramString2)
  {
    if (this.d == null)
      this.d = new s();
    this.d.a(new b(paramString1, paramString2));
    return this;
  }

  public r a(URI paramURI)
  {
    this.c = paramURI;
    return this;
  }

  public r a(ag[] paramArrayOfag)
  {
    int i = paramArrayOfag.length;
    for (int j = 0; j < i; j++)
      a(paramArrayOfag[j]);
    return this;
  }

  public r b(b.a.a.a.f paramf)
  {
    if (this.d == null)
      this.d = new s();
    this.d.b(paramf);
    return this;
  }

  public r b(String paramString)
  {
    if (paramString != null);
    for (URI localURI = URI.create(paramString); ; localURI = null)
    {
      this.c = localURI;
      return this;
    }
  }

  public r b(String paramString1, String paramString2)
  {
    if (this.d == null)
      this.d = new s();
    this.d.c(new b(paramString1, paramString2));
    return this;
  }

  public r c(b.a.a.a.f paramf)
  {
    if (this.d == null)
      this.d = new s();
    this.d.c(paramf);
    return this;
  }

  public r c(String paramString1, String paramString2)
  {
    return a(new b.a.a.a.l.n(paramString1, paramString2));
  }

  public b.a.a.a.f c(String paramString)
  {
    if (this.d != null)
      return this.d.c(paramString);
    return null;
  }

  public b.a.a.a.f d(String paramString)
  {
    if (this.d != null)
      return this.d.d(paramString);
    return null;
  }

  public b.a.a.a.f[] e(String paramString)
  {
    if (this.d != null)
      return this.d.b(paramString);
    return null;
  }

  public r f(String paramString)
  {
    if ((paramString == null) || (this.d == null));
    while (true)
    {
      return this;
      i locali = this.d.c();
      while (locali.hasNext())
      {
        if (!paramString.equalsIgnoreCase(locali.a().c()))
          continue;
        locali.remove();
      }
    }
  }

  public String h()
  {
    return this.a;
  }

  public ak i()
  {
    return this.b;
  }

  public URI j()
  {
    return this.c;
  }

  public b.a.a.a.n k()
  {
    return this.e;
  }

  public List<ag> l()
  {
    if (this.f != null)
      return new ArrayList(this.f);
    return new ArrayList();
  }

  public b.a.a.a.c.b.c m()
  {
    return this.g;
  }

  public q n()
  {
    Object localObject1;
    Object localObject2;
    if (this.c != null)
    {
      localObject1 = this.c;
      localObject2 = this.e;
      if ((this.f != null) && (!this.f.isEmpty()))
      {
        if ((localObject2 != null) || ((!"POST".equalsIgnoreCase(this.a)) && (!"PUT".equalsIgnoreCase(this.a))))
          break label143;
        localObject2 = new b.a.a.a.c.c.h(this.f, b.a.a.a.o.f.t);
      }
    }
    while (true)
    {
      Object localObject3;
      if (localObject2 == null)
      {
        localObject3 = new b(this.a);
        ((n)localObject3).a(this.b);
        ((n)localObject3).a((URI)localObject1);
        if (this.d != null)
          ((n)localObject3).a(this.d.b());
        ((n)localObject3).a(this.g);
        return localObject3;
        localObject1 = URI.create("/");
        break;
      }
      try
      {
        label143: URI localURI = new b.a.a.a.c.g.h((URI)localObject1).b(this.f).a();
        localObject1 = localURI;
        continue;
        a locala = new a(this.a);
        locala.a((b.a.a.a.n)localObject2);
        localObject3 = locala;
      }
      catch (URISyntaxException localURISyntaxException)
      {
      }
    }
  }

  static class a extends f
  {
    private final String a;

    a(String paramString)
    {
      this.a = paramString;
    }

    public String a()
    {
      return this.a;
    }
  }

  static class b extends n
  {
    private final String a;

    b(String paramString)
    {
      this.a = paramString;
    }

    public String a()
    {
      return this.a;
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.d.r
 * JD-Core Version:    0.6.0
 */