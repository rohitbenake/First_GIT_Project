package b.a.a.a.c;

import b.a.a.a.a.b;

@b
public class e extends n
{
  private static final long a = 6830063487001091803L;

  public e()
  {
  }

  public e(String paramString)
  {
    super(paramString);
  }

  public e(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.e
 * JD-Core Version:    0.6.0
 */