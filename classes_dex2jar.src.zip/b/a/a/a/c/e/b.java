package b.a.a.a.c.e;

@Deprecated
@b.a.a.a.a.b
public final class b
{
  public static final String a = "NTLM";
  public static final String b = "Digest";
  public static final String c = "Basic";
  public static final String d = "negotiate";
  public static final String e = "Kerberos";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.e.b
 * JD-Core Version:    0.6.0
 */