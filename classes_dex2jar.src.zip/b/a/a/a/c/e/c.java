package b.a.a.a.c.e;

@Deprecated
public abstract interface c
{
  public static final String a = "http.connection-manager.factory-class-name";
  public static final String b = "http.protocol.handle-redirects";
  public static final String d = "http.protocol.max-redirects";
  public static final String e = "http.protocol.allow-circular-redirects";
  public static final String g = "http.protocol.cookie-policy";
  public static final String i = "http.default-headers";
  public static final String j = "http.default-host";
  public static final String k = "http.conn-manager.timeout";
  public static final String t_ = "http.protocol.reject-relative-redirect";
  public static final String u_ = "http.protocol.handle-authentication";
  public static final String v_ = "http.virtual-host";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.e.c
 * JD-Core Version:    0.6.0
 */