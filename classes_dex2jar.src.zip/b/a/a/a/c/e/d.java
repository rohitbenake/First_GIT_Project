package b.a.a.a.c.e;

import b.a.a.a.a.c;
import b.a.a.a.m.j;
import b.a.a.a.r;
import java.util.Collection;

@Deprecated
@c
public class d extends b.a.a.a.m.f
{
  public d(j paramj)
  {
    super(paramj);
  }

  public void a(int paramInt)
  {
    this.a.b("http.protocol.max-redirects", paramInt);
  }

  public void a(long paramLong)
  {
    this.a.b("http.conn-manager.timeout", paramLong);
  }

  public void a(r paramr)
  {
    this.a.a("http.virtual-host", paramr);
  }

  @Deprecated
  public void a(String paramString)
  {
    this.a.a("http.connection-manager.factory-class-name", paramString);
  }

  public void a(Collection<b.a.a.a.f> paramCollection)
  {
    this.a.a("http.default-headers", paramCollection);
  }

  public void a(boolean paramBoolean)
  {
    this.a.b("http.protocol.handle-redirects", paramBoolean);
  }

  public void b(r paramr)
  {
    this.a.a("http.default-host", paramr);
  }

  public void b(String paramString)
  {
    this.a.a("http.protocol.cookie-policy", paramString);
  }

  public void b(boolean paramBoolean)
  {
    this.a.b("http.protocol.reject-relative-redirect", paramBoolean);
  }

  public void c(boolean paramBoolean)
  {
    this.a.b("http.protocol.allow-circular-redirects", paramBoolean);
  }

  public void d(boolean paramBoolean)
  {
    this.a.b("http.protocol.handle-authentication", paramBoolean);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.e.d
 * JD-Core Version:    0.6.0
 */