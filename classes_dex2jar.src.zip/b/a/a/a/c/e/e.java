package b.a.a.a.c.e;

import b.a.a.a.a.b;

@Deprecated
@b
public final class e
{
  public static final String a = "compatibility";
  public static final String b = "netscape";
  public static final String c = "rfc2109";
  public static final String d = "rfc2965";
  public static final String e = "best-match";
  public static final String f = "ignoreCookies";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.e.e
 * JD-Core Version:    0.6.0
 */