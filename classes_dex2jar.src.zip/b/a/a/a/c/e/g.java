package b.a.a.a.c.e;

import b.a.a.a.a.b;
import b.a.a.a.m.h;
import b.a.a.a.m.j;
import b.a.a.a.p.a;

@Deprecated
@b
public class g
{
  public static void a(j paramj, long paramLong)
  {
    a.a(paramj, "HTTP parameters");
    paramj.b("http.conn-manager.timeout", paramLong);
  }

  public static void a(j paramj, String paramString)
  {
    a.a(paramj, "HTTP parameters");
    paramj.a("http.protocol.cookie-policy", paramString);
  }

  public static void a(j paramj, boolean paramBoolean)
  {
    a.a(paramj, "HTTP parameters");
    paramj.b("http.protocol.handle-redirects", paramBoolean);
  }

  public static boolean a(j paramj)
  {
    a.a(paramj, "HTTP parameters");
    return paramj.a("http.protocol.handle-redirects", true);
  }

  public static void b(j paramj, boolean paramBoolean)
  {
    a.a(paramj, "HTTP parameters");
    paramj.b("http.protocol.handle-authentication", paramBoolean);
  }

  public static boolean b(j paramj)
  {
    a.a(paramj, "HTTP parameters");
    return paramj.a("http.protocol.handle-authentication", true);
  }

  public static String c(j paramj)
  {
    a.a(paramj, "HTTP parameters");
    String str = (String)paramj.a("http.protocol.cookie-policy");
    if (str == null)
      str = "best-match";
    return str;
  }

  public static long d(j paramj)
  {
    a.a(paramj, "HTTP parameters");
    Long localLong = (Long)paramj.a("http.conn-manager.timeout");
    if (localLong != null)
      return localLong.longValue();
    return h.f(paramj);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.e.g
 * JD-Core Version:    0.6.0
 */