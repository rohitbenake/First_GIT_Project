package b.a.a.a.c;

import b.a.a.a.a.b;
import java.io.IOException;

@b
public class f extends IOException
{
  private static final long a = -5596590843227115865L;

  public f()
  {
  }

  public f(String paramString)
  {
    super(paramString);
  }

  public f(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    initCause(paramThrowable);
  }

  public f(Throwable paramThrowable)
  {
    initCause(paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f
 * JD-Core Version:    0.6.0
 */