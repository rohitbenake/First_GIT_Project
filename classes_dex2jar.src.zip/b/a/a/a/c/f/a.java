package b.a.a.a.c.f;

@Deprecated
public abstract interface a
{
  public static final String a = "http.route";

  @Deprecated
  public static final String b = "http.scheme-registry";
  public static final String c = "http.cookiespec-registry";
  public static final String d = "http.cookie-spec";
  public static final String e = "http.cookie-origin";
  public static final String f = "http.cookie-store";
  public static final String g = "http.auth.credentials-provider";
  public static final String h = "http.auth.auth-cache";
  public static final String i = "http.auth.target-scope";
  public static final String j = "http.auth.proxy-scope";

  @Deprecated
  public static final String k = "http.auth.scheme-pref";
  public static final String l = "http.user-token";
  public static final String m = "http.authscheme-registry";
  public static final String n = "http.socket-factory-registry";
  public static final String o = "http.request-config";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.a
 * JD-Core Version:    0.6.0
 */