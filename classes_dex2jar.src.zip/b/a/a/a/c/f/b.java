package b.a.a.a.c.f;

import b.a.a.a.a.c;
import b.a.a.a.c.h;
import b.a.a.a.c.i;
import b.a.a.a.g.k;

@Deprecated
@c
public class b
  implements a
{
  private final b.a.a.a.o.g p;

  public b(b.a.a.a.o.g paramg)
  {
    b.a.a.a.p.a.a(paramg, "HTTP context");
    this.p = paramg;
  }

  public void a(b.a.a.a.b.g paramg)
  {
    this.p.a("http.authscheme-registry", paramg);
  }

  public void a(h paramh)
  {
    this.p.a("http.cookie-store", paramh);
  }

  public void a(i parami)
  {
    this.p.a("http.auth.credentials-provider", parami);
  }

  public void a(k paramk)
  {
    this.p.a("http.cookiespec-registry", paramk);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.b
 * JD-Core Version:    0.6.0
 */