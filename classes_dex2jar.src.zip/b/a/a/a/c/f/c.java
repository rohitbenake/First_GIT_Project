package b.a.a.a.c.f;

import b.a.a.a.b.f;
import b.a.a.a.g.j;
import b.a.a.a.o.g;
import java.net.URI;
import java.util.List;

@b.a.a.a.a.c
public class c extends b.a.a.a.o.h
{
  public static final String b = "http.route";
  public static final String c = "http.protocol.redirect-locations";
  public static final String d = "http.cookiespec-registry";
  public static final String e = "http.cookie-spec";
  public static final String f = "http.cookie-origin";
  public static final String g = "http.cookie-store";
  public static final String h = "http.auth.credentials-provider";
  public static final String i = "http.auth.auth-cache";
  public static final String j = "http.auth.target-scope";
  public static final String k = "http.auth.proxy-scope";
  public static final String l = "http.user-token";
  public static final String m = "http.authscheme-registry";
  public static final String n = "http.request-config";

  public c()
  {
  }

  public c(g paramg)
  {
    super(paramg);
  }

  public static c b(g paramg)
  {
    if ((paramg instanceof c))
      return (c)paramg;
    return new c(paramg);
  }

  private <T> b.a.a.a.e.b<T> b(String paramString, Class<T> paramClass)
  {
    return (b.a.a.a.e.b)a(paramString, b.a.a.a.e.b.class);
  }

  public static c c()
  {
    return new c(new b.a.a.a.o.a());
  }

  public <T> T a(Class<T> paramClass)
  {
    return a("http.user-token", paramClass);
  }

  public void a(b.a.a.a.c.a parama)
  {
    a("http.auth.auth-cache", parama);
  }

  public void a(b.a.a.a.c.b.c paramc)
  {
    a("http.request-config", paramc);
  }

  public void a(b.a.a.a.c.h paramh)
  {
    a("http.cookie-store", paramh);
  }

  public void a(b.a.a.a.c.i parami)
  {
    a("http.auth.credentials-provider", parami);
  }

  public void a(b.a.a.a.e.b<j> paramb)
  {
    a("http.cookiespec-registry", paramb);
  }

  public void a(Object paramObject)
  {
    a("http.user-token", paramObject);
  }

  public void b(b.a.a.a.e.b<f> paramb)
  {
    a("http.authscheme-registry", paramb);
  }

  public b.a.a.a.f.b.e d()
  {
    return (b.a.a.a.f.b.e)a("http.route", b.a.a.a.f.b.b.class);
  }

  public List<URI> e()
  {
    return (List)a("http.protocol.redirect-locations", List.class);
  }

  public b.a.a.a.c.h f()
  {
    return (b.a.a.a.c.h)a("http.cookie-store", b.a.a.a.c.h.class);
  }

  public b.a.a.a.g.h g()
  {
    return (b.a.a.a.g.h)a("http.cookie-spec", b.a.a.a.g.h.class);
  }

  public b.a.a.a.g.e h()
  {
    return (b.a.a.a.g.e)a("http.cookie-origin", b.a.a.a.g.e.class);
  }

  public b.a.a.a.e.b<j> i()
  {
    return b("http.cookiespec-registry", j.class);
  }

  public b.a.a.a.e.b<f> j()
  {
    return b("http.authscheme-registry", f.class);
  }

  public b.a.a.a.c.i k()
  {
    return (b.a.a.a.c.i)a("http.auth.credentials-provider", b.a.a.a.c.i.class);
  }

  public b.a.a.a.c.a l()
  {
    return (b.a.a.a.c.a)a("http.auth.auth-cache", b.a.a.a.c.a.class);
  }

  public b.a.a.a.b.i m()
  {
    return (b.a.a.a.b.i)a("http.auth.target-scope", b.a.a.a.b.i.class);
  }

  public b.a.a.a.b.i n()
  {
    return (b.a.a.a.b.i)a("http.auth.proxy-scope", b.a.a.a.b.i.class);
  }

  public Object o()
  {
    return a("http.user-token");
  }

  public b.a.a.a.c.b.c p()
  {
    b.a.a.a.c.b.c localc = (b.a.a.a.c.b.c)a("http.request-config", b.a.a.a.c.b.c.class);
    if (localc != null)
      return localc;
    return b.a.a.a.c.b.c.a;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.c
 * JD-Core Version:    0.6.0
 */