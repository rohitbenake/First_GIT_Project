package b.a.a.a.c.f;

import b.a.a.a.a.b;
import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.u;
import b.a.a.a.w;
import java.io.IOException;

@b
public class d
  implements w
{
  public void a(u paramu, g paramg)
    throws p, IOException
  {
    if (!paramu.a("Accept-Encoding"))
      paramu.a("Accept-Encoding", "gzip,deflate");
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.d
 * JD-Core Version:    0.6.0
 */