package b.a.a.a.c.f;

import b.a.a.a.am;
import b.a.a.a.c.d.q;
import b.a.a.a.f;
import b.a.a.a.g.j;
import b.a.a.a.g.o;
import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.p.a;
import b.a.a.a.p.k;
import b.a.a.a.r;
import b.a.a.a.u;
import b.a.a.a.w;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@b.a.a.a.a.b
public class e
  implements w
{
  public b.a.a.a.i.b a = new b.a.a.a.i.b(getClass());

  public void a(u paramu, g paramg)
    throws p, IOException
  {
    a.a(paramu, "HTTP request");
    a.a(paramg, "HTTP context");
    if (paramu.h().a().equalsIgnoreCase("CONNECT"))
      return;
    c localc = c.b(paramg);
    b.a.a.a.c.h localh = localc.f();
    if (localh == null)
    {
      this.a.a("Cookie store not specified in HTTP context");
      return;
    }
    b.a.a.a.e.b localb = localc.i();
    if (localb == null)
    {
      this.a.a("CookieSpec registry not specified in HTTP context");
      return;
    }
    r localr = localc.v();
    if (localr == null)
    {
      this.a.a("Target host not set in the context");
      return;
    }
    b.a.a.a.f.b.e locale = localc.d();
    if (locale == null)
    {
      this.a.a("Connection route not set in the context");
      return;
    }
    String str1 = localc.p().e();
    if (str1 == null)
      str1 = "best-match";
    if (this.a.a())
      this.a.a("CookieSpec selected: " + str1);
    Object localObject;
    if ((paramu instanceof q))
      localObject = ((q)paramu).l();
    while (true)
    {
      String str2;
      label214: int i;
      label250: b.a.a.a.g.e locale1;
      label258: j localj;
      if (localObject != null)
      {
        str2 = ((URI)localObject).getPath();
        String str3 = localr.a();
        i = localr.b();
        if (i < 0)
          i = locale.a().b();
        if (i < 0)
          break label364;
        if (k.a(str2))
          break label370;
        boolean bool = locale.j();
        locale1 = new b.a.a.a.g.e(str3, i, str2, bool);
        localj = (j)localb.c(str1);
        if (localj != null)
          break label377;
        throw new p("Unsupported cookie policy: " + str1);
      }
      try
      {
        URI localURI = new URI(paramu.h().c());
        localObject = localURI;
        continue;
        str2 = null;
        break label214;
        label364: i = 0;
        break label250;
        label370: str2 = "/";
        break label258;
        label377: b.a.a.a.g.h localh1 = localj.a(localc);
        ArrayList localArrayList1 = new ArrayList(localh.b());
        ArrayList localArrayList2 = new ArrayList();
        Date localDate = new Date();
        Iterator localIterator1 = localArrayList1.iterator();
        while (localIterator1.hasNext())
        {
          b.a.a.a.g.b localb2 = (b.a.a.a.g.b)localIterator1.next();
          if (!localb2.a(localDate))
          {
            if (!localh1.b(localb2, locale1))
              continue;
            if (this.a.a())
              this.a.a("Cookie " + localb2 + " match " + locale1);
            localArrayList2.add(localb2);
            continue;
          }
          if (!this.a.a())
            continue;
          this.a.a("Cookie " + localb2 + " expired");
        }
        if (!localArrayList2.isEmpty())
        {
          Iterator localIterator3 = localh1.a(localArrayList2).iterator();
          while (localIterator3.hasNext())
            paramu.a((f)localIterator3.next());
        }
        int j = localh1.a();
        if (j > 0)
        {
          int k = 0;
          Iterator localIterator2 = localArrayList2.iterator();
          while (localIterator2.hasNext())
          {
            b.a.a.a.g.b localb1 = (b.a.a.a.g.b)localIterator2.next();
            if ((j == localb1.k()) && ((localb1 instanceof o)))
              continue;
            k = 1;
          }
          if (k != 0)
          {
            f localf = localh1.b();
            if (localf != null)
              paramu.a(localf);
          }
        }
        paramg.a("http.cookie-spec", localh1);
        paramg.a("http.cookie-origin", locale1);
        return;
      }
      catch (URISyntaxException localURISyntaxException)
      {
        localObject = null;
      }
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.e
 * JD-Core Version:    0.6.0
 */