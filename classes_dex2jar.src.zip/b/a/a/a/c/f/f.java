package b.a.a.a.c.f;

import b.a.a.a.b.d;
import b.a.a.a.b.h;
import b.a.a.a.b.n;
import b.a.a.a.f.b.e;
import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.r;
import b.a.a.a.u;
import b.a.a.a.w;
import java.io.IOException;

@b.a.a.a.a.b
public class f
  implements w
{
  public b.a.a.a.i.b a = new b.a.a.a.i.b(getClass());

  private void a(r paramr, d paramd, b.a.a.a.b.i parami, b.a.a.a.c.i parami1)
  {
    String str = paramd.a();
    if (this.a.a())
      this.a.a("Re-using cached '" + str + "' auth scheme for " + paramr);
    n localn = parami1.a(new h(paramr, h.c, str));
    if (localn != null)
    {
      if ("BASIC".equalsIgnoreCase(paramd.a()))
        parami.a(b.a.a.a.b.c.b);
      while (true)
      {
        parami.a(paramd, localn);
        return;
        parami.a(b.a.a.a.b.c.e);
      }
    }
    this.a.a("No credentials for preemptive authentication");
  }

  public void a(u paramu, g paramg)
    throws p, IOException
  {
    b.a.a.a.p.a.a(paramu, "HTTP request");
    b.a.a.a.p.a.a(paramg, "HTTP context");
    c localc = c.b(paramg);
    b.a.a.a.c.a locala = localc.l();
    if (locala == null)
      this.a.a("Auth cache not set in the context");
    b.a.a.a.c.i locali;
    r localr2;
    b.a.a.a.b.i locali2;
    d locald1;
    do
    {
      do
      {
        return;
        locali = localc.k();
        if (locali == null)
        {
          this.a.a("Credentials provider not set in the context");
          return;
        }
        e locale = localc.d();
        if (locale == null)
        {
          this.a.a("Route info not set in the context");
          return;
        }
        r localr1 = localc.v();
        if (localr1 == null)
        {
          this.a.a("Target host not set in the context");
          return;
        }
        if (localr1.b() < 0)
          localr1 = new r(localr1.a(), locale.a().b(), localr1.c());
        b.a.a.a.b.i locali1 = localc.m();
        if ((locali1 != null) && (locali1.b() == b.a.a.a.b.c.a))
        {
          d locald2 = locala.a(localr1);
          if (locald2 != null)
            a(localr1, locald2, locali1, locali);
        }
        localr2 = locale.e();
        locali2 = localc.n();
      }
      while ((localr2 == null) || (locali2 == null) || (locali2.b() != b.a.a.a.b.c.a));
      locald1 = locala.a(localr2);
    }
    while (locald1 == null);
    a(localr2, locald1, locali2, locali);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.f
 * JD-Core Version:    0.6.0
 */