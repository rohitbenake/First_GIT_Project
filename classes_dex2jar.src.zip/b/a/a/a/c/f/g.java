package b.a.a.a.c.f;

import b.a.a.a.b.d;
import b.a.a.a.b.i;
import b.a.a.a.b.j;
import b.a.a.a.b.m;
import b.a.a.a.b.n;
import b.a.a.a.f;
import b.a.a.a.u;
import b.a.a.a.w;
import java.util.Queue;

@Deprecated
abstract class g
  implements w
{
  final b.a.a.a.i.b a = new b.a.a.a.i.b(getClass());

  private f a(d paramd, n paramn, u paramu, b.a.a.a.o.g paramg)
    throws j
  {
    b.a.a.a.p.b.a(paramd, "Auth scheme");
    if ((paramd instanceof m))
      return ((m)paramd).a(paramn, paramu, paramg);
    return paramd.a(paramn, paramu);
  }

  private void a(d paramd)
  {
    b.a.a.a.p.b.a(paramd, "Auth scheme");
  }

  void a(i parami, u paramu, b.a.a.a.o.g paramg)
  {
    d locald1 = parami.c();
    n localn1 = parami.d();
    switch (1.a[parami.b().ordinal()])
    {
    default:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      if (locald1 != null);
      try
      {
        paramu.a(a(locald1, localn1, paramu, paramg));
        while (true)
        {
          return;
          a(locald1);
          if (!locald1.c())
            break;
          return;
          Queue localQueue = parami.e();
          if (localQueue == null)
            break label256;
          while (!localQueue.isEmpty())
          {
            b.a.a.a.b.b localb = (b.a.a.a.b.b)localQueue.remove();
            d locald2 = localb.a();
            n localn2 = localb.b();
            parami.a(locald2, localn2);
            if (this.a.a())
              this.a.a("Generating response to an authentication challenge using " + locald2.a() + " scheme");
            try
            {
              paramu.a(a(locald2, localn2, paramu, paramg));
              return;
            }
            catch (j localj2)
            {
            }
            if (!this.a.c())
              continue;
            this.a.c(locald2 + " authentication error: " + localj2.getMessage());
          }
        }
        label256: a(locald1);
      }
      catch (j localj1)
      {
        while (!this.a.b());
        this.a.b(locald1 + " authentication error: " + localj1.getMessage());
      }
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.g
 * JD-Core Version:    0.6.0
 */