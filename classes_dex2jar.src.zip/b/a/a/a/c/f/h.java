package b.a.a.a.c.f;

import b.a.a.a.am;
import b.a.a.a.f.b.e;
import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.p.a;
import b.a.a.a.u;
import b.a.a.a.w;
import java.io.IOException;

@b.a.a.a.a.b
public class h
  implements w
{
  private static final String b = "Proxy-Connection";
  public b.a.a.a.i.b a = new b.a.a.a.i.b(getClass());

  public void a(u paramu, g paramg)
    throws p, IOException
  {
    a.a(paramu, "HTTP request");
    if (paramu.h().a().equalsIgnoreCase("CONNECT"))
      paramu.b("Proxy-Connection", "Keep-Alive");
    e locale;
    do
    {
      return;
      locale = c.b(paramg).d();
      if (locale == null)
      {
        this.a.a("Connection route not set in the context");
        return;
      }
      if (((locale.d() != 1) && (!locale.g())) || (paramu.a("Connection")))
        continue;
      paramu.a("Connection", "Keep-Alive");
    }
    while ((locale.d() != 2) || (locale.g()) || (paramu.a("Proxy-Connection")));
    paramu.a("Proxy-Connection", "Keep-Alive");
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.h
 * JD-Core Version:    0.6.0
 */