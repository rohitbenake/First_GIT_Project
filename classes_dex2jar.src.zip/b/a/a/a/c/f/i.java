package b.a.a.a.c.f;

import b.a.a.a.a.b;
import b.a.a.a.am;
import b.a.a.a.f;
import b.a.a.a.m.j;
import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.p.a;
import b.a.a.a.u;
import b.a.a.a.w;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

@b
public class i
  implements w
{
  private final Collection<? extends f> a;

  public i()
  {
    this(null);
  }

  public i(Collection<? extends f> paramCollection)
  {
    this.a = paramCollection;
  }

  public void a(u paramu, g paramg)
    throws p, IOException
  {
    a.a(paramu, "HTTP request");
    if (paramu.h().a().equalsIgnoreCase("CONNECT"));
    while (true)
    {
      return;
      Collection localCollection = (Collection)paramu.g().a("http.default-headers");
      if (localCollection == null)
        localCollection = this.a;
      if (localCollection == null)
        continue;
      Iterator localIterator = localCollection.iterator();
      while (localIterator.hasNext())
        paramu.a((f)localIterator.next());
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.i
 * JD-Core Version:    0.6.0
 */