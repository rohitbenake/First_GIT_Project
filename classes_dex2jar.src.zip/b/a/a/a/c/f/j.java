package b.a.a.a.c.f;

import b.a.a.a.a.b;
import b.a.a.a.ac;
import b.a.a.a.ak;
import b.a.a.a.am;
import b.a.a.a.n;
import b.a.a.a.o;
import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.p.a;
import b.a.a.a.u;
import b.a.a.a.w;
import java.io.IOException;

@b
public class j
  implements w
{
  public void a(u paramu, g paramg)
    throws p, IOException
  {
    a.a(paramu, "HTTP request");
    if ((!paramu.a("Expect")) && ((paramu instanceof o)))
    {
      ak localak = paramu.h().b();
      n localn = ((o)paramu).c();
      if ((localn != null) && (localn.b() != 0L) && (!localak.d(ac.c)) && (c.b(paramg).p().a()))
        paramu.a("Expect", "100-continue");
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.j
 * JD-Core Version:    0.6.0
 */