package b.a.a.a.c.f;

import b.a.a.a.am;
import b.a.a.a.b.i;
import b.a.a.a.p;
import b.a.a.a.p.a;
import b.a.a.a.u;
import java.io.IOException;

@Deprecated
@b.a.a.a.a.b
public class l extends g
{
  public void a(u paramu, b.a.a.a.o.g paramg)
    throws p, IOException
  {
    a.a(paramu, "HTTP request");
    a.a(paramg, "HTTP context");
    if (paramu.h().a().equalsIgnoreCase("CONNECT"));
    do
      return;
    while (paramu.a("Authorization"));
    i locali = (i)paramg.a("http.auth.target-scope");
    if (locali == null)
    {
      this.a.a("Target auth state not set in the context");
      return;
    }
    if (this.a.a())
      this.a.a("Target auth state: " + locali.b());
    a(locali, paramu, paramg);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.l
 * JD-Core Version:    0.6.0
 */