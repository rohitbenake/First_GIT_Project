package b.a.a.a.c.f;

import b.a.a.a.b.d;
import b.a.a.a.b.i;
import b.a.a.a.f.c.f;
import b.a.a.a.f.c.j;
import b.a.a.a.p;
import b.a.a.a.r;
import b.a.a.a.x;
import b.a.a.a.z;
import java.io.IOException;

@Deprecated
@b.a.a.a.a.b
public class m
  implements z
{
  public b.a.a.a.i.b a = new b.a.a.a.i.b(getClass());

  private void a(b.a.a.a.c.a parama, r paramr, d paramd)
  {
    if (this.a.a())
      this.a.a("Caching '" + paramd.a() + "' auth scheme for " + paramr);
    parama.a(paramr, paramd);
  }

  private boolean a(i parami)
  {
    d locald = parami.c();
    if ((locald == null) || (!locald.d()));
    String str;
    do
    {
      return false;
      str = locald.a();
    }
    while ((!str.equalsIgnoreCase("Basic")) && (!str.equalsIgnoreCase("Digest")));
    return true;
  }

  private void b(b.a.a.a.c.a parama, r paramr, d paramd)
  {
    if (this.a.a())
      this.a.a("Removing from cache '" + paramd.a() + "' auth scheme for " + paramr);
    parama.b(paramr);
  }

  public void a(x paramx, b.a.a.a.o.g paramg)
    throws p, IOException
  {
    b.a.a.a.p.a.a(paramx, "HTTP request");
    b.a.a.a.p.a.a(paramg, "HTTP context");
    Object localObject = (b.a.a.a.c.a)paramg.a("http.auth.auth-cache");
    r localr1 = (r)paramg.a("http.target_host");
    i locali1 = (i)paramg.a("http.auth.target-scope");
    if ((localr1 != null) && (locali1 != null))
    {
      if (this.a.a())
        this.a.a("Target auth state: " + locali1.b());
      if (a(locali1))
      {
        j localj = (j)paramg.a("http.scheme-registry");
        if (localr1.b() < 0)
        {
          f localf = localj.a(localr1);
          localr1 = new r(localr1.a(), localf.a(localr1.b()), localr1.c());
        }
        if (localObject == null)
        {
          localObject = new b.a.a.a.j.b.g();
          paramg.a("http.auth.auth-cache", localObject);
        }
        switch (1.a[locali1.b().ordinal()])
        {
        default:
        case 1:
        case 2:
        }
      }
    }
    r localr2;
    i locali2;
    while (true)
    {
      localr2 = (r)paramg.a("http.proxy_host");
      locali2 = (i)paramg.a("http.auth.proxy-scope");
      if ((localr2 != null) && (locali2 != null))
      {
        if (this.a.a())
          this.a.a("Proxy auth state: " + locali2.b());
        if (a(locali2))
          if (localObject == null)
          {
            localObject = new b.a.a.a.j.b.g();
            paramg.a("http.auth.auth-cache", localObject);
          }
      }
      switch (1.a[locali2.b().ordinal()])
      {
      default:
        return;
        a((b.a.a.a.c.a)localObject, localr1, locali1.c());
        continue;
        b((b.a.a.a.c.a)localObject, localr1, locali1.c());
      case 1:
      case 2:
      }
    }
    a((b.a.a.a.c.a)localObject, localr2, locali2.c());
    return;
    b((b.a.a.a.c.a)localObject, localr2, locali2.c());
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.m
 * JD-Core Version:    0.6.0
 */