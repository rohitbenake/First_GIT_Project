package b.a.a.a.c.f;

import b.a.a.a.p;
import b.a.a.a.x;
import b.a.a.a.z;
import java.io.IOException;
import java.util.Locale;

@b.a.a.a.a.b
public class n
  implements z
{
  public static final String a = "http.client.response.uncompressed";

  public void a(x paramx, b.a.a.a.o.g paramg)
    throws p, IOException
  {
    b.a.a.a.n localn = paramx.b();
    int j;
    b.a.a.a.g localg;
    String str;
    if ((localn != null) && (localn.b() != 0L))
    {
      b.a.a.a.f localf = localn.g();
      if (localf != null)
      {
        b.a.a.a.g[] arrayOfg = localf.e();
        int i = arrayOfg.length;
        j = 0;
        if (i < 0)
        {
          localg = arrayOfg[0];
          str = localg.a().toLowerCase(Locale.ENGLISH);
          if ((!"gzip".equals(str)) && (!"x-gzip".equals(str)))
            break label150;
          paramx.a(new b.a.a.a.c.c.f(paramx.b()));
          j = 1;
        }
        if (j != 0)
        {
          paramx.e("Content-Length");
          paramx.e("Content-Encoding");
          paramx.e("Content-MD5");
        }
      }
    }
    label150: 
    do
    {
      return;
      if (!"deflate".equals(str))
        continue;
      paramx.a(new b.a.a.a.c.c.b(paramx.b()));
      j = 1;
      break;
    }
    while ("identity".equals(str));
    throw new p("Unsupported Content-Coding: " + localg.a());
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.n
 * JD-Core Version:    0.6.0
 */