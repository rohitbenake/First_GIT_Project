package b.a.a.a.c.f;

import b.a.a.a.f;
import b.a.a.a.g.e;
import b.a.a.a.g.l;
import b.a.a.a.i;
import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.p.a;
import b.a.a.a.x;
import b.a.a.a.z;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

@b.a.a.a.a.b
public class o
  implements z
{
  public b.a.a.a.i.b a = new b.a.a.a.i.b(getClass());

  private static String a(b.a.a.a.g.b paramb)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(paramb.a());
    localStringBuilder.append("=\"");
    String str = paramb.b();
    if (str != null)
    {
      if (str.length() > 100)
        str = str.substring(0, 100) + "...";
      localStringBuilder.append(str);
    }
    localStringBuilder.append("\"");
    localStringBuilder.append(", version:");
    localStringBuilder.append(Integer.toString(paramb.k()));
    localStringBuilder.append(", domain:");
    localStringBuilder.append(paramb.g());
    localStringBuilder.append(", path:");
    localStringBuilder.append(paramb.h());
    localStringBuilder.append(", expiry:");
    localStringBuilder.append(paramb.e());
    return localStringBuilder.toString();
  }

  private void a(i parami, b.a.a.a.g.h paramh, e parame, b.a.a.a.c.h paramh1)
  {
    while (parami.hasNext())
    {
      f localf = parami.a();
      try
      {
        Iterator localIterator = paramh.a(localf, parame).iterator();
        while (localIterator.hasNext())
        {
          b.a.a.a.g.b localb = (b.a.a.a.g.b)localIterator.next();
          try
          {
            paramh.a(localb, parame);
            paramh1.a(localb);
            if (!this.a.a())
              continue;
            this.a.a("Cookie accepted [" + a(localb) + "]");
          }
          catch (l locall2)
          {
          }
          if (!this.a.c())
            continue;
          this.a.c("Cookie rejected [" + a(localb) + "] " + locall2.getMessage());
        }
      }
      catch (l locall1)
      {
      }
      if (!this.a.c())
        continue;
      this.a.c("Invalid cookie header: \"" + localf + "\". " + locall1.getMessage());
    }
  }

  public void a(x paramx, g paramg)
    throws p, IOException
  {
    a.a(paramx, "HTTP request");
    a.a(paramg, "HTTP context");
    c localc = c.b(paramg);
    b.a.a.a.g.h localh = localc.g();
    if (localh == null)
      this.a.a("Cookie spec not specified in HTTP context");
    b.a.a.a.c.h localh1;
    e locale;
    do
    {
      return;
      localh1 = localc.f();
      if (localh1 == null)
      {
        this.a.a("Cookie store not specified in HTTP context");
        return;
      }
      locale = localc.h();
      if (locale == null)
      {
        this.a.a("Cookie origin not specified in HTTP context");
        return;
      }
      a(paramx.f("Set-Cookie"), localh, locale, localh1);
    }
    while (localh.a() <= 0);
    a(paramx.f("Set-Cookie2"), localh, locale, localh1);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.f.o
 * JD-Core Version:    0.6.0
 */