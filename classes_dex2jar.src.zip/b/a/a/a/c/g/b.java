package b.a.a.a.c.g;

import b.a.a.a.p.a;
import java.lang.ref.SoftReference;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

@b.a.a.a.a.b
public final class b
{
  public static final String a = "EEE, dd MMM yyyy HH:mm:ss zzz";
  public static final String b = "EEE, dd-MMM-yy HH:mm:ss zzz";
  public static final String c = "EEE MMM d HH:mm:ss yyyy";
  public static final TimeZone d;
  private static final String[] e = { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM d HH:mm:ss yyyy" };
  private static final Date f;

  static
  {
    d = TimeZone.getTimeZone("GMT");
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTimeZone(d);
    localCalendar.set(2000, 0, 1, 0, 0, 0);
    localCalendar.set(14, 0);
    f = localCalendar.getTime();
  }

  public static String a(Date paramDate)
  {
    return a(paramDate, "EEE, dd MMM yyyy HH:mm:ss zzz");
  }

  public static String a(Date paramDate, String paramString)
  {
    a.a(paramDate, "Date");
    a.a(paramString, "Pattern");
    return a.a(paramString).format(paramDate);
  }

  public static Date a(String paramString)
  {
    return a(paramString, null, null);
  }

  public static Date a(String paramString, String[] paramArrayOfString)
  {
    return a(paramString, paramArrayOfString, null);
  }

  public static Date a(String paramString, String[] paramArrayOfString, Date paramDate)
  {
    a.a(paramString, "Date value");
    String[] arrayOfString;
    Date localDate1;
    label21: String str;
    int i;
    if (paramArrayOfString != null)
    {
      arrayOfString = paramArrayOfString;
      if (paramDate == null)
        break label140;
      localDate1 = paramDate;
      str = paramString;
      if ((str.length() > 1) && (str.startsWith("'")) && (str.endsWith("'")))
        str = str.substring(1, -1 + str.length());
      i = arrayOfString.length;
    }
    for (int j = 0; ; j++)
    {
      if (j >= i)
        break label154;
      SimpleDateFormat localSimpleDateFormat = a.a(arrayOfString[j]);
      localSimpleDateFormat.set2DigitYearStart(localDate1);
      ParsePosition localParsePosition = new ParsePosition(0);
      Date localDate2 = localSimpleDateFormat.parse(str, localParsePosition);
      if (localParsePosition.getIndex() != 0)
      {
        return localDate2;
        arrayOfString = e;
        break;
        label140: localDate1 = f;
        break label21;
      }
    }
    label154: return null;
  }

  public static void a()
  {
    a.a();
  }

  static final class a
  {
    private static final ThreadLocal<SoftReference<Map<String, SimpleDateFormat>>> a = new ThreadLocal()
    {
      protected SoftReference<Map<String, SimpleDateFormat>> a()
      {
        return new SoftReference(new HashMap());
      }
    };

    public static SimpleDateFormat a(String paramString)
    {
      Object localObject = (Map)((SoftReference)a.get()).get();
      if (localObject == null)
      {
        localObject = new HashMap();
        a.set(new SoftReference(localObject));
      }
      SimpleDateFormat localSimpleDateFormat = (SimpleDateFormat)((Map)localObject).get(paramString);
      if (localSimpleDateFormat == null)
      {
        localSimpleDateFormat = new SimpleDateFormat(paramString, Locale.US);
        localSimpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        ((Map)localObject).put(paramString, localSimpleDateFormat);
      }
      return (SimpleDateFormat)localSimpleDateFormat;
    }

    public static void a()
    {
      a.remove();
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.b
 * JD-Core Version:    0.6.0
 */