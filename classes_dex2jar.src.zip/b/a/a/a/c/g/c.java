package b.a.a.a.c.g;

import b.a.a.a.c.j;
import b.a.a.a.n;
import b.a.a.a.p.g;
import b.a.a.a.x;
import java.io.Closeable;
import java.io.IOException;

public class c
{
  // ERROR //
  public static void a(b.a.a.a.c.d.c paramc)
  {
    // Byte code:
    //   0: aload_0
    //   1: ifnull +29 -> 30
    //   4: aload_0
    //   5: invokeinterface 18 1 0
    //   10: invokestatic 23	b/a/a/a/p/g:b	(Lb/a/a/a/n;)V
    //   13: aload_0
    //   14: invokeinterface 26 1 0
    //   19: return
    //   20: astore_1
    //   21: aload_0
    //   22: invokeinterface 26 1 0
    //   27: aload_1
    //   28: athrow
    //   29: astore_2
    //   30: return
    //
    // Exception table:
    //   from	to	target	type
    //   4	13	20	finally
    //   13	19	29	java/io/IOException
    //   21	29	29	java/io/IOException
  }

  public static void a(j paramj)
  {
    if ((paramj != null) && ((paramj instanceof Closeable)));
    try
    {
      ((Closeable)paramj).close();
      return;
    }
    catch (IOException localIOException)
    {
    }
  }

  public static void a(x paramx)
  {
    n localn;
    if (paramx != null)
    {
      localn = paramx.b();
      if (localn == null);
    }
    try
    {
      g.b(localn);
      return;
    }
    catch (IOException localIOException)
    {
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.c
 * JD-Core Version:    0.6.0
 */