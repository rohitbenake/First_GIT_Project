package b.a.a.a.c.g;

import b.a.a.a.a.b;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@b
public class e
  implements d
{
  private final Method a;

  public e()
    throws ClassNotFoundException
  {
    Class localClass = Class.forName("java.net.IDN");
    try
    {
      this.a = localClass.getMethod("toUnicode", new Class[] { String.class });
      return;
    }
    catch (SecurityException localSecurityException)
    {
      throw new IllegalStateException(localSecurityException.getMessage(), localSecurityException);
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
    }
    throw new IllegalStateException(localNoSuchMethodException.getMessage(), localNoSuchMethodException);
  }

  public String a(String paramString)
  {
    Throwable localThrowable;
    try
    {
      String str = (String)this.a.invoke(null, new Object[] { paramString });
      return str;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalStateException(localIllegalAccessException.getMessage(), localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      localThrowable = localInvocationTargetException.getCause();
    }
    throw new RuntimeException(localThrowable.getMessage(), localThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.e
 * JD-Core Version:    0.6.0
 */