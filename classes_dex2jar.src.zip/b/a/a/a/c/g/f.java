package b.a.a.a.c.g;

import b.a.a.a.a.b;

@b
public class f
{
  private static final d a;

  static
  {
    try
    {
      localObject = new e();
      a = (d)localObject;
      return;
    }
    catch (Exception localException)
    {
      while (true)
        Object localObject = new g();
    }
  }

  public static String a(String paramString)
  {
    return a.a(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.f
 * JD-Core Version:    0.6.0
 */