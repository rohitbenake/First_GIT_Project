package b.a.a.a.c.g;

import b.a.a.a.a.b;
import java.util.StringTokenizer;

@b
public class g
  implements d
{
  private static final int a = 36;
  private static final int b = 1;
  private static final int c = 26;
  private static final int d = 38;
  private static final int e = 700;
  private static final int f = 72;
  private static final int g = 128;
  private static final char h = '-';
  private static final String i = "xn--";

  private int a(char paramChar)
  {
    if ((paramChar >= 'A') && (paramChar <= 'Z'))
      return paramChar - 'A';
    if ((paramChar >= 'a') && (paramChar <= 'z'))
      return paramChar - 'a';
    if ((paramChar >= '0') && (paramChar <= '9'))
      return 26 + (paramChar - '0');
    throw new IllegalArgumentException("illegal digit: " + paramChar);
  }

  private int a(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramBoolean);
    int k;
    int m;
    for (int j = paramInt1 / 700; ; j = paramInt1 / 2)
    {
      k = j + j / paramInt2;
      for (m = 0; k > 455; m += 36)
        k /= 35;
    }
    return m + k * 36 / (k + 38);
  }

  public String a(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder(paramString.length());
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ".");
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = localStringTokenizer.nextToken();
      if (localStringBuilder.length() > 0)
        localStringBuilder.append('.');
      if (str.startsWith("xn--"))
        str = b(str.substring(4));
      localStringBuilder.append(str);
    }
    return localStringBuilder.toString();
  }

  protected String b(String paramString)
  {
    String str = paramString;
    int j = 128;
    int k = 72;
    StringBuilder localStringBuilder = new StringBuilder(str.length());
    int m = str.lastIndexOf('-');
    int n = 0;
    if (m != -1)
    {
      localStringBuilder.append(str.subSequence(0, m));
      str = str.substring(m + 1);
    }
    if (str.length() > 0)
    {
      int i1 = n;
      int i2 = 1;
      int i3 = 36;
      label87: int i6;
      int i7;
      if (str.length() == 0)
      {
        i6 = n - i1;
        i7 = 1 + localStringBuilder.length();
        if (i1 != 0)
          break label260;
      }
      label258: label260: for (boolean bool = true; ; bool = false)
      {
        k = a(i6, i7, bool);
        j += n / (1 + localStringBuilder.length());
        int i8 = n % (1 + localStringBuilder.length());
        localStringBuilder.insert(i8, (char)j);
        n = i8 + 1;
        break;
        char c1 = str.charAt(0);
        str = str.substring(1);
        int i4 = a(c1);
        n += i4 * i2;
        int i5;
        if (i3 <= k + 1)
          i5 = 1;
        while (true)
        {
          if (i4 < i5)
            break label258;
          i2 *= (36 - i5);
          i3 += 36;
          break;
          if (i3 >= k + 26)
          {
            i5 = 26;
            continue;
          }
          i5 = i3 - k;
        }
        break label87;
      }
    }
    return localStringBuilder.toString();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.g
 * JD-Core Version:    0.6.0
 */