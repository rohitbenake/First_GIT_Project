package b.a.a.a.c.g;

import b.a.a.a.ag;
import b.a.a.a.f.f.a;
import b.a.a.a.l.n;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@b.a.a.a.a.c
public class h
{
  private String a;
  private String b;
  private String c;
  private String d;
  private String e;
  private String f;
  private int g;
  private String h;
  private String i;
  private String j;
  private List<ag> k;
  private String l;
  private String m;
  private String n;

  public h()
  {
    this.g = -1;
  }

  public h(String paramString)
    throws URISyntaxException
  {
    a(new URI(paramString));
  }

  public h(URI paramURI)
  {
    a(paramURI);
  }

  private List<ag> a(String paramString, Charset paramCharset)
  {
    if ((paramString != null) && (paramString.length() > 0))
      return j.a(paramString, paramCharset);
    return null;
  }

  private void a(URI paramURI)
  {
    this.a = paramURI.getScheme();
    this.b = paramURI.getRawSchemeSpecificPart();
    this.c = paramURI.getRawAuthority();
    this.f = paramURI.getHost();
    this.g = paramURI.getPort();
    this.e = paramURI.getRawUserInfo();
    this.d = paramURI.getUserInfo();
    this.i = paramURI.getRawPath();
    this.h = paramURI.getPath();
    this.j = paramURI.getRawQuery();
    this.k = a(paramURI.getRawQuery(), b.a.a.a.c.e);
    this.n = paramURI.getRawFragment();
    this.m = paramURI.getFragment();
  }

  private String c(List<ag> paramList)
  {
    return j.a(paramList, b.a.a.a.c.e);
  }

  private String h(String paramString)
  {
    return j.b(paramString, b.a.a.a.c.e);
  }

  private String i(String paramString)
  {
    return j.d(paramString, b.a.a.a.c.e);
  }

  private String j(String paramString)
  {
    return j.c(paramString, b.a.a.a.c.e);
  }

  private static String k(String paramString)
  {
    String str = paramString;
    if (str == null)
      return null;
    for (int i1 = 0; ; i1++)
    {
      if ((i1 < str.length()) && (str.charAt(i1) == '/'))
        continue;
      if (i1 > 1)
        str = str.substring(i1 - 1);
      return str;
    }
  }

  private String m()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (this.a != null)
      localStringBuilder.append(this.a).append(':');
    if (this.b != null)
    {
      localStringBuilder.append(this.b);
      if (this.n == null)
        break label345;
      localStringBuilder.append("#").append(this.n);
    }
    while (true)
    {
      return localStringBuilder.toString();
      if (this.c != null)
      {
        localStringBuilder.append("//").append(this.c);
        label92: if (this.i == null)
          break label263;
        localStringBuilder.append(k(this.i));
      }
      while (true)
      {
        if (this.j == null)
          break label289;
        localStringBuilder.append("?").append(this.j);
        break;
        if (this.f == null)
          break label92;
        localStringBuilder.append("//");
        if (this.e != null)
        {
          localStringBuilder.append(this.e).append("@");
          label170: if (!a.e(this.f))
            break label251;
          localStringBuilder.append("[").append(this.f).append("]");
        }
        while (true)
        {
          if (this.g < 0)
            break label261;
          localStringBuilder.append(":").append(this.g);
          break;
          if (this.d == null)
            break label170;
          localStringBuilder.append(h(this.d)).append("@");
          break label170;
          label251: localStringBuilder.append(this.f);
        }
        label261: break label92;
        label263: if (this.h == null)
          continue;
        localStringBuilder.append(i(k(this.h)));
      }
      label289: if (this.k != null)
      {
        localStringBuilder.append("?").append(c(this.k));
        break;
      }
      if (this.l == null)
        break;
      localStringBuilder.append("?").append(j(this.l));
      break;
      label345: if (this.m == null)
        continue;
      localStringBuilder.append("#").append(j(this.m));
    }
  }

  public h a(int paramInt)
  {
    if (paramInt < 0)
      paramInt = -1;
    this.g = paramInt;
    this.b = null;
    this.c = null;
    return this;
  }

  public h a(String paramString)
  {
    this.a = paramString;
    return this;
  }

  public h a(String paramString1, String paramString2)
  {
    return b(paramString1 + ':' + paramString2);
  }

  public h a(List<ag> paramList)
  {
    if (this.k == null)
      this.k = new ArrayList();
    while (true)
    {
      this.k.addAll(paramList);
      this.j = null;
      this.b = null;
      this.l = null;
      return this;
      this.k.clear();
    }
  }

  public h a(ag[] paramArrayOfag)
  {
    if (this.k == null)
      this.k = new ArrayList();
    while (true)
    {
      int i1 = paramArrayOfag.length;
      for (int i2 = 0; i2 < i1; i2++)
      {
        ag localag = paramArrayOfag[i2];
        this.k.add(localag);
      }
      this.k.clear();
    }
    this.j = null;
    this.b = null;
    this.l = null;
    return this;
  }

  public URI a()
    throws URISyntaxException
  {
    return new URI(m());
  }

  public h b()
  {
    this.k = null;
    this.l = null;
    this.j = null;
    this.b = null;
    return this;
  }

  public h b(String paramString)
  {
    this.d = paramString;
    this.b = null;
    this.c = null;
    this.e = null;
    return this;
  }

  public h b(String paramString1, String paramString2)
  {
    if (this.k == null)
      this.k = new ArrayList();
    this.k.add(new n(paramString1, paramString2));
    this.j = null;
    this.b = null;
    this.l = null;
    return this;
  }

  public h b(List<ag> paramList)
  {
    if (this.k == null)
      this.k = new ArrayList();
    this.k.addAll(paramList);
    this.j = null;
    this.b = null;
    this.l = null;
    return this;
  }

  public h c()
  {
    this.k = null;
    this.j = null;
    this.b = null;
    return this;
  }

  public h c(String paramString)
  {
    this.f = paramString;
    this.b = null;
    this.c = null;
    return this;
  }

  public h c(String paramString1, String paramString2)
  {
    if (this.k == null)
      this.k = new ArrayList();
    if (!this.k.isEmpty())
    {
      Iterator localIterator = this.k.iterator();
      while (localIterator.hasNext())
      {
        if (!((ag)localIterator.next()).a().equals(paramString1))
          continue;
        localIterator.remove();
      }
    }
    this.k.add(new n(paramString1, paramString2));
    this.j = null;
    this.b = null;
    this.l = null;
    return this;
  }

  public h d(String paramString)
  {
    this.h = paramString;
    this.b = null;
    this.i = null;
    return this;
  }

  public boolean d()
  {
    return this.a != null;
  }

  @Deprecated
  public h e(String paramString)
  {
    this.k = a(paramString, b.a.a.a.c.e);
    this.l = null;
    this.j = null;
    this.b = null;
    return this;
  }

  public boolean e()
  {
    return this.h == null;
  }

  public h f(String paramString)
  {
    this.l = paramString;
    this.j = null;
    this.b = null;
    this.k = null;
    return this;
  }

  public String f()
  {
    return this.a;
  }

  public h g(String paramString)
  {
    this.m = paramString;
    this.n = null;
    return this;
  }

  public String g()
  {
    return this.d;
  }

  public String h()
  {
    return this.f;
  }

  public int i()
  {
    return this.g;
  }

  public String j()
  {
    return this.h;
  }

  public List<ag> k()
  {
    if (this.k != null)
      return new ArrayList(this.k);
    return new ArrayList();
  }

  public String l()
  {
    return this.m;
  }

  public String toString()
  {
    return m();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.h
 * JD-Core Version:    0.6.0
 */