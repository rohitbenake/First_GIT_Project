package b.a.a.a.c.g;

import b.a.a.a.a.b;
import b.a.a.a.p.a;
import b.a.a.a.p.k;
import b.a.a.a.r;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Stack;

@b
public class i
{
  @Deprecated
  public static URI a(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5)
    throws URISyntaxException
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (paramString2 != null)
    {
      if (paramString1 != null)
      {
        localStringBuilder.append(paramString1);
        localStringBuilder.append("://");
      }
      localStringBuilder.append(paramString2);
      if (paramInt > 0)
      {
        localStringBuilder.append(':');
        localStringBuilder.append(paramInt);
      }
    }
    if ((paramString3 == null) || (!paramString3.startsWith("/")))
      localStringBuilder.append('/');
    if (paramString3 != null)
      localStringBuilder.append(paramString3);
    if (paramString4 != null)
    {
      localStringBuilder.append('?');
      localStringBuilder.append(paramString4);
    }
    if (paramString5 != null)
    {
      localStringBuilder.append('#');
      localStringBuilder.append(paramString5);
    }
    return new URI(localStringBuilder.toString());
  }

  public static URI a(URI paramURI)
    throws URISyntaxException
  {
    a.a(paramURI, "URI");
    if (paramURI.isOpaque())
      return paramURI;
    h localh = new h(paramURI);
    if (localh.g() != null)
      localh.b(null);
    if (k.a(localh.j()))
      localh.d("/");
    if (localh.h() != null)
      localh.c(localh.h().toLowerCase(Locale.ENGLISH));
    localh.g(null);
    return localh.a();
  }

  public static URI a(URI paramURI, r paramr)
    throws URISyntaxException
  {
    return a(paramURI, paramr, false);
  }

  public static URI a(URI paramURI, r paramr, List<URI> paramList)
    throws URISyntaxException
  {
    a.a(paramURI, "Request URI");
    h localh;
    if ((paramList == null) || (paramList.isEmpty()))
      localh = new h(paramURI);
    while (true)
    {
      if (localh.l() == null)
        localh.g(paramURI.getFragment());
      if ((paramr != null) && (!localh.d()))
      {
        localh.a(paramr.c());
        localh.c(paramr.a());
        localh.a(paramr.b());
      }
      return localh.a();
      localh = new h((URI)paramList.get(-1 + paramList.size()));
      String str = localh.l();
      for (int i = -1 + paramList.size(); (str == null) && (i >= 0); i--)
        str = ((URI)paramList.get(i)).getFragment();
      localh.g(str);
    }
  }

  public static URI a(URI paramURI, r paramr, boolean paramBoolean)
    throws URISyntaxException
  {
    a.a(paramURI, "URI");
    if (paramURI.isOpaque())
      return paramURI;
    h localh = new h(paramURI);
    if (paramr != null)
    {
      localh.a(paramr.c());
      localh.c(paramr.a());
      localh.a(paramr.b());
    }
    while (true)
    {
      if (paramBoolean)
        localh.g(null);
      if (k.a(localh.j()))
        localh.d("/");
      return localh.a();
      localh.a(null);
      localh.c(null);
      localh.a(-1);
    }
  }

  public static URI a(URI paramURI, String paramString)
  {
    return a(paramURI, URI.create(paramString));
  }

  public static URI a(URI paramURI1, URI paramURI2)
  {
    a.a(paramURI1, "Base URI");
    a.a(paramURI2, "Reference URI");
    URI localURI1 = paramURI2;
    String str1 = localURI1.toString();
    if (str1.startsWith("?"))
      return b(paramURI1, localURI1);
    if (str1.length() == 0);
    for (int i = 1; ; i = 0)
    {
      if (i != 0)
        localURI1 = URI.create("#");
      URI localURI2 = paramURI1.resolve(localURI1);
      if (i != 0)
      {
        String str2 = localURI2.toString();
        localURI2 = URI.create(str2.substring(0, str2.indexOf('#')));
      }
      return c(localURI2);
    }
  }

  public static r b(URI paramURI)
  {
    if (paramURI == null);
    while (true)
    {
      return null;
      if (!paramURI.isAbsolute())
        continue;
      int i = paramURI.getPort();
      String str1 = paramURI.getHost();
      int k;
      int m;
      label129: int i2;
      if (str1 == null)
      {
        str1 = paramURI.getAuthority();
        if (str1 != null)
        {
          int j = str1.indexOf('@');
          if (j >= 0)
          {
            if (str1.length() <= j + 1)
              break label129;
            str1 = str1.substring(j + 1);
          }
          while (true)
            if (str1 != null)
            {
              k = str1.indexOf(':');
              if (k >= 0)
              {
                m = k + 1;
                int n = 0;
                int i1 = m;
                while (true)
                  if ((i1 < str1.length()) && (Character.isDigit(str1.charAt(i1))))
                  {
                    n++;
                    i1++;
                    continue;
                    str1 = null;
                    break;
                  }
                if (n <= 0)
                  break;
                i2 = m + n;
              }
            }
        }
      }
      try
      {
        int i3 = Integer.parseInt(str1.substring(m, i2));
        i = i3;
        label162: str1 = str1.substring(0, k);
        String str2 = paramURI.getScheme();
        if (k.b(str1))
          continue;
        return new r(str1, i, str2);
      }
      catch (NumberFormatException localNumberFormatException)
      {
        break label162;
      }
    }
  }

  private static URI b(URI paramURI1, URI paramURI2)
  {
    String str = paramURI1.toString();
    if (str.indexOf('?') > -1)
      str = str.substring(0, str.indexOf('?'));
    return URI.create(str + paramURI2.toString());
  }

  private static URI c(URI paramURI)
  {
    URI localURI1;
    if ((paramURI.isOpaque()) || (paramURI.getAuthority() == null))
      localURI1 = paramURI;
    while (true)
    {
      return localURI1;
      a.a(paramURI.isAbsolute(), "Base URI must be absolute");
      String str1;
      Stack localStack;
      int j;
      label60: String str3;
      if (paramURI.getPath() == null)
      {
        str1 = "";
        String[] arrayOfString = str1.split("/");
        localStack = new Stack();
        int i = arrayOfString.length;
        j = 0;
        if (j >= i)
          break label143;
        str3 = arrayOfString[j];
        if ((str3.length() != 0) && (!".".equals(str3)))
          break label105;
      }
      while (true)
      {
        j++;
        break label60;
        str1 = paramURI.getPath();
        break;
        label105: if ("..".equals(str3))
        {
          if (localStack.isEmpty())
            continue;
          localStack.pop();
          continue;
        }
        localStack.push(str3);
      }
      label143: StringBuilder localStringBuilder1 = new StringBuilder();
      Iterator localIterator = localStack.iterator();
      while (localIterator.hasNext())
      {
        String str2 = (String)localIterator.next();
        localStringBuilder1.append('/').append(str2);
      }
      if (str1.lastIndexOf('/') == -1 + str1.length())
        localStringBuilder1.append('/');
      try
      {
        localURI1 = new URI(paramURI.getScheme().toLowerCase(Locale.ENGLISH), paramURI.getAuthority().toLowerCase(Locale.ENGLISH), localStringBuilder1.toString(), null, null);
        if ((paramURI.getQuery() == null) && (paramURI.getFragment() == null))
          continue;
        StringBuilder localStringBuilder2 = new StringBuilder(localURI1.toASCIIString());
        if (paramURI.getQuery() != null)
          localStringBuilder2.append('?').append(paramURI.getRawQuery());
        if (paramURI.getFragment() != null)
          localStringBuilder2.append('#').append(paramURI.getRawFragment());
        URI localURI2 = URI.create(localStringBuilder2.toString());
        return localURI2;
      }
      catch (URISyntaxException localURISyntaxException)
      {
      }
    }
    throw new IllegalArgumentException(localURISyntaxException);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.i
 * JD-Core Version:    0.6.0
 */