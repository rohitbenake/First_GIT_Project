package b.a.a.a.c.g;

import b.a.a.a.a.b;
import b.a.a.a.ag;
import b.a.a.a.c;
import b.a.a.a.l.x;
import b.a.a.a.p.d;
import java.io.IOException;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

@b
public class j
{
  public static final String a = "application/x-www-form-urlencoded";
  private static final char b = '&';
  private static final char c = ';';
  private static final String d = "=";
  private static final char[] e = { 38, 59 };
  private static final String f = "[" + new String(e) + "]";
  private static final BitSet g = new BitSet(256);
  private static final BitSet h = new BitSet(256);
  private static final BitSet i = new BitSet(256);
  private static final BitSet j = new BitSet(256);
  private static final BitSet k = new BitSet(256);
  private static final BitSet l = new BitSet(256);
  private static final BitSet m = new BitSet(256);
  private static final int n = 16;

  static
  {
    for (int i1 = 97; i1 <= 122; i1++)
      g.set(i1);
    for (int i2 = 65; i2 <= 90; i2++)
      g.set(i2);
    for (int i3 = 48; i3 <= 57; i3++)
      g.set(i3);
    g.set(95);
    g.set(45);
    g.set(46);
    g.set(42);
    m.or(g);
    g.set(33);
    g.set(126);
    g.set(39);
    g.set(40);
    g.set(41);
    h.set(44);
    h.set(59);
    h.set(58);
    h.set(36);
    h.set(38);
    h.set(43);
    h.set(61);
    i.or(g);
    i.or(h);
    j.or(g);
    j.set(47);
    j.set(59);
    j.set(58);
    j.set(64);
    j.set(38);
    j.set(61);
    j.set(43);
    j.set(36);
    j.set(44);
    l.set(59);
    l.set(47);
    l.set(63);
    l.set(58);
    l.set(64);
    l.set(38);
    l.set(61);
    l.set(43);
    l.set(36);
    l.set(44);
    l.set(91);
    l.set(93);
    k.or(l);
    k.or(g);
  }

  public static String a(Iterable<? extends ag> paramIterable, char paramChar, Charset paramCharset)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = paramIterable.iterator();
    while (localIterator.hasNext())
    {
      ag localag = (ag)localIterator.next();
      String str1 = f(localag.a(), paramCharset);
      String str2 = f(localag.b(), paramCharset);
      if (localStringBuilder.length() > 0)
        localStringBuilder.append(paramChar);
      localStringBuilder.append(str1);
      if (str2 == null)
        continue;
      localStringBuilder.append("=");
      localStringBuilder.append(str2);
    }
    return localStringBuilder.toString();
  }

  public static String a(Iterable<? extends ag> paramIterable, Charset paramCharset)
  {
    return a(paramIterable, '&', paramCharset);
  }

  private static String a(String paramString1, String paramString2)
  {
    if (paramString1 == null)
      return null;
    if (paramString2 != null);
    for (Charset localCharset = Charset.forName(paramString2); ; localCharset = c.e)
      return a(paramString1, localCharset, true);
  }

  private static String a(String paramString, Charset paramCharset, BitSet paramBitSet, boolean paramBoolean)
  {
    if (paramString == null)
      return null;
    StringBuilder localStringBuilder = new StringBuilder();
    ByteBuffer localByteBuffer = paramCharset.encode(paramString);
    while (localByteBuffer.hasRemaining())
    {
      int i1 = 0xFF & localByteBuffer.get();
      if (paramBitSet.get(i1))
      {
        localStringBuilder.append((char)i1);
        continue;
      }
      if ((paramBoolean) && (i1 == 32))
      {
        localStringBuilder.append('+');
        continue;
      }
      localStringBuilder.append("%");
      char c1 = Character.toUpperCase(Character.forDigit(0xF & i1 >> 4, 16));
      char c2 = Character.toUpperCase(Character.forDigit(i1 & 0xF, 16));
      localStringBuilder.append(c1);
      localStringBuilder.append(c2);
    }
    return localStringBuilder.toString();
  }

  private static String a(String paramString, Charset paramCharset, boolean paramBoolean)
  {
    if (paramString == null)
      return null;
    ByteBuffer localByteBuffer = ByteBuffer.allocate(paramString.length());
    CharBuffer localCharBuffer = CharBuffer.wrap(paramString);
    while (localCharBuffer.hasRemaining())
    {
      int i1 = localCharBuffer.get();
      if ((i1 == 37) && (localCharBuffer.remaining() >= 2))
      {
        char c1 = localCharBuffer.get();
        char c2 = localCharBuffer.get();
        int i2 = Character.digit(c1, 16);
        int i3 = Character.digit(c2, 16);
        if ((i2 != -1) && (i3 != -1))
        {
          localByteBuffer.put((byte)(i3 + (i2 << 4)));
          continue;
        }
        localByteBuffer.put(37);
        localByteBuffer.put((byte)c1);
        localByteBuffer.put((byte)c2);
        continue;
      }
      if ((paramBoolean) && (i1 == 43))
      {
        localByteBuffer.put(32);
        continue;
      }
      localByteBuffer.put((byte)i1);
    }
    localByteBuffer.flip();
    return paramCharset.decode(localByteBuffer).toString();
  }

  public static String a(List<? extends ag> paramList, char paramChar, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ag localag = (ag)localIterator.next();
      String str1 = b(localag.a(), paramString);
      String str2 = b(localag.b(), paramString);
      if (localStringBuilder.length() > 0)
        localStringBuilder.append(paramChar);
      localStringBuilder.append(str1);
      if (str2 == null)
        continue;
      localStringBuilder.append("=");
      localStringBuilder.append(str2);
    }
    return localStringBuilder.toString();
  }

  public static String a(List<? extends ag> paramList, String paramString)
  {
    return a(paramList, '&', paramString);
  }

  public static List<ag> a(b.a.a.a.n paramn)
    throws IOException
  {
    b.a.a.a.h.g localg = b.a.a.a.h.g.a(paramn);
    if ((localg != null) && (localg.a().equalsIgnoreCase("application/x-www-form-urlencoded")))
    {
      String str = b.a.a.a.p.g.a(paramn, c.f);
      if ((str != null) && (str.length() > 0))
      {
        Charset localCharset = localg.b();
        if (localCharset == null)
          localCharset = b.a.a.a.o.f.t;
        return a(str, localCharset, e);
      }
    }
    return Collections.emptyList();
  }

  public static List<ag> a(String paramString, Charset paramCharset)
  {
    return a(paramString, paramCharset, e);
  }

  public static List<ag> a(String paramString, Charset paramCharset, char[] paramArrayOfChar)
  {
    Object localObject;
    if (paramString == null)
      localObject = Collections.emptyList();
    while (true)
    {
      return localObject;
      b.a.a.a.l.g localg = b.a.a.a.l.g.b;
      d locald = new d(paramString.length());
      locald.a(paramString);
      x localx = new x(0, locald.e());
      localObject = new ArrayList();
      while (!localx.d())
      {
        ag localag = localg.a(locald, localx, paramArrayOfChar);
        if (localag.a().length() <= 0)
          continue;
        ((List)localObject).add(new b.a.a.a.l.n(e(localag.a(), paramCharset), e(localag.b(), paramCharset)));
      }
    }
  }

  public static List<ag> a(URI paramURI, String paramString)
  {
    String str = paramURI.getRawQuery();
    if ((str != null) && (str.length() > 0))
    {
      ArrayList localArrayList = new ArrayList();
      a(localArrayList, new Scanner(str), f, paramString);
      return localArrayList;
    }
    return Collections.emptyList();
  }

  public static void a(List<ag> paramList, Scanner paramScanner, String paramString)
  {
    a(paramList, paramScanner, f, paramString);
  }

  public static void a(List<ag> paramList, Scanner paramScanner, String paramString1, String paramString2)
  {
    paramScanner.useDelimiter(paramString1);
    if (paramScanner.hasNext())
    {
      String str1 = paramScanner.next();
      int i1 = str1.indexOf("=");
      String str2;
      if (i1 != -1)
        str2 = a(str1.substring(0, i1).trim(), paramString2);
      for (String str3 = a(str1.substring(i1 + 1).trim(), paramString2); ; str3 = null)
      {
        paramList.add(new b.a.a.a.l.n(str2, str3));
        break;
        str2 = a(str1.trim(), paramString2);
      }
    }
  }

  private static String b(String paramString1, String paramString2)
  {
    if (paramString1 == null)
      return null;
    if (paramString2 != null);
    for (Charset localCharset = Charset.forName(paramString2); ; localCharset = c.e)
      return a(paramString1, localCharset, m, true);
  }

  static String b(String paramString, Charset paramCharset)
  {
    return a(paramString, paramCharset, i, false);
  }

  public static boolean b(b.a.a.a.n paramn)
  {
    b.a.a.a.f localf = paramn.h();
    boolean bool = false;
    if (localf != null)
    {
      b.a.a.a.g[] arrayOfg = localf.e();
      int i1 = arrayOfg.length;
      bool = false;
      if (i1 > 0)
        bool = arrayOfg[0].a().equalsIgnoreCase("application/x-www-form-urlencoded");
    }
    return bool;
  }

  static String c(String paramString, Charset paramCharset)
  {
    return a(paramString, paramCharset, k, false);
  }

  static String d(String paramString, Charset paramCharset)
  {
    return a(paramString, paramCharset, j, false);
  }

  private static String e(String paramString, Charset paramCharset)
  {
    if (paramString == null)
      return null;
    if (paramCharset != null);
    while (true)
    {
      return a(paramString, paramCharset, true);
      paramCharset = c.e;
    }
  }

  private static String f(String paramString, Charset paramCharset)
  {
    if (paramString == null)
      return null;
    if (paramCharset != null);
    while (true)
    {
      return a(paramString, paramCharset, m, true);
      paramCharset = c.e;
    }
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.g.j
 * JD-Core Version:    0.6.0
 */