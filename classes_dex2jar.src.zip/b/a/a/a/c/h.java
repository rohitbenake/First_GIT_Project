package b.a.a.a.c;

import b.a.a.a.g.b;
import java.util.Date;
import java.util.List;

public abstract interface h
{
  public abstract void a();

  public abstract void a(b paramb);

  public abstract boolean a(Date paramDate);

  public abstract List<b> b();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.h
 * JD-Core Version:    0.6.0
 */