package b.a.a.a.c;

import b.a.a.a.b.h;
import b.a.a.a.b.n;

public abstract interface i
{
  public abstract n a(h paramh);

  public abstract void a();

  public abstract void a(h paramh, n paramn);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.i
 * JD-Core Version:    0.6.0
 */