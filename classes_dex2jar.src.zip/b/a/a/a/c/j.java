package b.a.a.a.c;

import b.a.a.a.c.d.q;
import b.a.a.a.f.c;
import b.a.a.a.o.g;
import b.a.a.a.u;
import b.a.a.a.x;
import java.io.IOException;

public abstract interface j
{
  @Deprecated
  public abstract b.a.a.a.m.j a();

  public abstract x a(q paramq)
    throws IOException, f;

  public abstract x a(q paramq, g paramg)
    throws IOException, f;

  public abstract x a(b.a.a.a.r paramr, u paramu)
    throws IOException, f;

  public abstract x a(b.a.a.a.r paramr, u paramu, g paramg)
    throws IOException, f;

  public abstract <T> T a(q paramq, r<? extends T> paramr)
    throws IOException, f;

  public abstract <T> T a(q paramq, r<? extends T> paramr, g paramg)
    throws IOException, f;

  public abstract <T> T a(b.a.a.a.r paramr, u paramu, r<? extends T> paramr1)
    throws IOException, f;

  public abstract <T> T a(b.a.a.a.r paramr, u paramu, r<? extends T> paramr1, g paramg)
    throws IOException, f;

  @Deprecated
  public abstract c b();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.j
 * JD-Core Version:    0.6.0
 */