package b.a.a.a.c;

import b.a.a.a.a.b;

@b
public class l extends f
{
  private static final long a = -7186627969477257933L;
  private final int b;

  public l(int paramInt, String paramString)
  {
    super(paramString);
    this.b = paramInt;
  }

  public int a()
  {
    return this.b;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.l
 * JD-Core Version:    0.6.0
 */