package b.a.a.a.c;

import b.a.a.a.a.b;
import b.a.a.a.aj;

@b
public class m extends aj
{
  private static final long a = 82685265288806048L;

  public m()
  {
  }

  public m(String paramString)
  {
    super(paramString);
  }

  public m(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.m
 * JD-Core Version:    0.6.0
 */