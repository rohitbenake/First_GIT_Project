package b.a.a.a.c;

import b.a.a.a.a.b;
import b.a.a.a.aj;

@b
public class n extends aj
{
  private static final long a = 4418824536372559326L;

  public n()
  {
  }

  public n(String paramString)
  {
    super(paramString);
  }

  public n(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.n
 * JD-Core Version:    0.6.0
 */