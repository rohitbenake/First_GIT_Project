package b.a.a.a.c;

import b.a.a.a.aj;
import b.a.a.a.o.g;
import b.a.a.a.x;
import java.net.URI;

@Deprecated
public abstract interface o
{
  public abstract boolean a(x paramx, g paramg);

  public abstract URI b(x paramx, g paramg)
    throws aj;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.o
 * JD-Core Version:    0.6.0
 */