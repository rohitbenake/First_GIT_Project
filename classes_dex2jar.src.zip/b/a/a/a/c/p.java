package b.a.a.a.c;

import b.a.a.a.aj;
import b.a.a.a.c.d.q;
import b.a.a.a.o.g;
import b.a.a.a.u;
import b.a.a.a.x;

public abstract interface p
{
  public abstract boolean a(u paramu, x paramx, g paramg)
    throws aj;

  public abstract q b(u paramu, x paramx, g paramg)
    throws aj;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.p
 * JD-Core Version:    0.6.0
 */