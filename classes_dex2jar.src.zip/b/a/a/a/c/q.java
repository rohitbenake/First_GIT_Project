package b.a.a.a.c;

import b.a.a.a.o.g;
import b.a.a.a.p;
import b.a.a.a.r;
import b.a.a.a.u;
import b.a.a.a.x;
import java.io.IOException;

@Deprecated
public abstract interface q
{
  public abstract x a(r paramr, u paramu, g paramg)
    throws p, IOException;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.q
 * JD-Core Version:    0.6.0
 */