package b.a.a.a.c;

import b.a.a.a.x;
import java.io.IOException;

public abstract interface r<T>
{
  public abstract T a(x paramx)
    throws f, IOException;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.r
 * JD-Core Version:    0.6.0
 */