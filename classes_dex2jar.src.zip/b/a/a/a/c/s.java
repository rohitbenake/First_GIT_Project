package b.a.a.a.c;

import b.a.a.a.o.g;
import b.a.a.a.x;

public abstract interface s
{
  public abstract long a();

  public abstract boolean a(x paramx, int paramInt, g paramg);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.c.s
 * JD-Core Version:    0.6.0
 */