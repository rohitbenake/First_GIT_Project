package b.a.a.a;

import java.io.IOException;

public class d extends IOException
{
  private static final long a = -924287689552495383L;

  public d(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.d
 * JD-Core Version:    0.6.0
 */