package b.a.a.a.d;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class a<T>
  implements b, Future<T>
{
  private final c<T> a;
  private volatile boolean b;
  private volatile boolean c;
  private volatile T d;
  private volatile Exception e;

  public a(c<T> paramc)
  {
    this.a = paramc;
  }

  private T b()
    throws ExecutionException
  {
    if (this.e != null)
      throw new ExecutionException(this.e);
    return this.d;
  }

  public boolean a()
  {
    return cancel(true);
  }

  public boolean a(Exception paramException)
  {
    monitorenter;
    try
    {
      if (this.b)
        return false;
      this.b = true;
      this.e = paramException;
      notifyAll();
      monitorexit;
      if (this.a != null)
      {
        this.a.a(paramException);
        return true;
      }
    }
    finally
    {
      monitorexit;
    }
    return true;
  }

  public boolean a(T paramT)
  {
    monitorenter;
    try
    {
      if (this.b)
        return false;
      this.b = true;
      this.d = paramT;
      notifyAll();
      monitorexit;
      if (this.a != null)
      {
        this.a.a(paramT);
        return true;
      }
    }
    finally
    {
      monitorexit;
    }
    return true;
  }

  public boolean cancel(boolean paramBoolean)
  {
    monitorenter;
    try
    {
      if (this.b)
        return false;
      this.b = true;
      this.c = true;
      notifyAll();
      monitorexit;
      if (this.a != null)
      {
        this.a.a();
        return true;
      }
    }
    finally
    {
      monitorexit;
    }
    return true;
  }

  public T get()
    throws InterruptedException, ExecutionException
  {
    monitorenter;
    try
    {
      while (!this.b)
        wait();
    }
    finally
    {
      monitorexit;
    }
    Object localObject2 = b();
    monitorexit;
    return localObject2;
  }

  public T get(long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException, ExecutionException, TimeoutException
  {
    monitorenter;
    long l1;
    long l2;
    long l3;
    Object localObject2;
    try
    {
      b.a.a.a.p.a.a(paramTimeUnit, "Time unit");
      l1 = paramTimeUnit.toMillis(paramLong);
      if (l1 <= 0L)
        l2 = 0L;
      while (true)
      {
        l3 = l1;
        if (!this.b)
          break;
        Object localObject3 = b();
        localObject2 = localObject3;
        return localObject2;
        l2 = System.currentTimeMillis();
      }
      if (l3 <= 0L)
        throw new TimeoutException();
    }
    finally
    {
      monitorexit;
    }
    do
    {
      wait(l3);
      if (this.b)
      {
        localObject2 = b();
        break;
      }
      l3 = l1 - (System.currentTimeMillis() - l2);
    }
    while (l3 > 0L);
    throw new TimeoutException();
  }

  public boolean isCancelled()
  {
    return this.c;
  }

  public boolean isDone()
  {
    return this.b;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.d.a
 * JD-Core Version:    0.6.0
 */