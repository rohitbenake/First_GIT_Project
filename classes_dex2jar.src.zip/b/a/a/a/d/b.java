package b.a.a.a.d;

public abstract interface b
{
  public abstract boolean a();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.d.b
 * JD-Core Version:    0.6.0
 */