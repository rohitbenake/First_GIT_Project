package b.a.a.a.f.a;

@Deprecated
public abstract interface a
{

  @Deprecated
  public static final String D_ = "http.connection.max-status-line-garbage";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.f.a.a
 * JD-Core Version:    0.6.0
 */