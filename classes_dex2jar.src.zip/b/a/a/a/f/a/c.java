package b.a.a.a.f.a;

@Deprecated
public abstract interface c
{
  public static final String E_ = "http.conn-manager.timeout";
  public static final String F_ = "http.conn-manager.max-per-route";
  public static final String G_ = "http.conn-manager.max-total";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.f.a.c
 * JD-Core Version:    0.6.0
 */