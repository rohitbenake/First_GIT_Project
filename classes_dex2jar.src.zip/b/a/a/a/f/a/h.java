package b.a.a.a.f.a;

@Deprecated
public abstract interface h
{
  public static final String H_ = "http.route.default-proxy";
  public static final String I_ = "http.route.local-address";
  public static final String c = "http.route.forced-route";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.f.a.h
 * JD-Core Version:    0.6.0
 */