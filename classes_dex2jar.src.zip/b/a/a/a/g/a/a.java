package b.a.a.a.g.a;

@Deprecated
public abstract interface a
{
  public static final String B_ = "http.protocol.cookie-datepatterns";
  public static final String C_ = "http.protocol.single-cookie-header";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.g.a.a
 * JD-Core Version:    0.6.0
 */