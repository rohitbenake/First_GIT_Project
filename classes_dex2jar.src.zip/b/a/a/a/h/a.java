package b.a.a.a.h;

import b.a.a.a.a.c;
import b.a.a.a.f;
import b.a.a.a.l.b;
import b.a.a.a.n;
import java.io.IOException;

@c
public abstract class a
  implements n
{
  protected static final int a = 4096;
  protected f b;
  protected f c;
  protected boolean d;

  public void a(f paramf)
  {
    this.b = paramf;
  }

  public void a(String paramString)
  {
    b localb = null;
    if (paramString != null)
      localb = new b("Content-Type", paramString);
    a(localb);
  }

  public void a(boolean paramBoolean)
  {
    this.d = paramBoolean;
  }

  public void b(f paramf)
  {
    this.c = paramf;
  }

  public void b(String paramString)
  {
    b localb = null;
    if (paramString != null)
      localb = new b("Content-Encoding", paramString);
    b(localb);
  }

  @Deprecated
  public void c()
    throws IOException
  {
  }

  public boolean e()
  {
    return this.d;
  }

  public f g()
  {
    return this.c;
  }

  public f h()
  {
    return this.b;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append('[');
    if (this.b != null)
    {
      localStringBuilder.append("Content-Type: ");
      localStringBuilder.append(this.b.d());
      localStringBuilder.append(',');
    }
    if (this.c != null)
    {
      localStringBuilder.append("Content-Encoding: ");
      localStringBuilder.append(this.c.d());
      localStringBuilder.append(',');
    }
    long l = b();
    if (l >= 0L)
    {
      localStringBuilder.append("Content-Length: ");
      localStringBuilder.append(l);
      localStringBuilder.append(',');
    }
    localStringBuilder.append("Chunked: ");
    localStringBuilder.append(this.d);
    localStringBuilder.append(']');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.h.a
 * JD-Core Version:    0.6.0
 */