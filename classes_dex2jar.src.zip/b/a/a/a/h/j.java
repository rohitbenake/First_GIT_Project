package b.a.a.a.h;

import b.a.a.a.a.c;
import b.a.a.a.f;
import b.a.a.a.n;
import b.a.a.a.p.a;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

@c
public class j
  implements n
{
  protected n d;

  public j(n paramn)
  {
    this.d = ((n)a.a(paramn, "Wrapped entity"));
  }

  public InputStream a()
    throws IOException
  {
    return this.d.a();
  }

  public void a(OutputStream paramOutputStream)
    throws IOException
  {
    this.d.a(paramOutputStream);
  }

  public long b()
  {
    return this.d.b();
  }

  @Deprecated
  public void c()
    throws IOException
  {
    this.d.c();
  }

  public boolean d()
  {
    return this.d.d();
  }

  public boolean e()
  {
    return this.d.e();
  }

  public boolean f()
  {
    return this.d.f();
  }

  public f g()
  {
    return this.d.g();
  }

  public f h()
  {
    return this.d.h();
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.h.j
 * JD-Core Version:    0.6.0
 */