package b.a.a.a.h;

import b.a.a.a.a.c;
import b.a.a.a.o.f;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;

@c
public class m extends a
  implements Cloneable
{
  protected final byte[] e;

  public m(String paramString)
    throws UnsupportedEncodingException
  {
    this(paramString, g.m);
  }

  public m(String paramString, g paramg)
    throws UnsupportedCharsetException
  {
    b.a.a.a.p.a.a(paramString, "Source string");
    Charset localCharset;
    if (paramg != null)
      localCharset = paramg.b();
    while (true)
    {
      if (localCharset == null)
        localCharset = f.t;
      try
      {
        this.e = paramString.getBytes(localCharset.name());
        if (paramg != null)
          a(paramg.toString());
        return;
        localCharset = null;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
      }
    }
    throw new UnsupportedCharsetException(localCharset.name());
  }

  public m(String paramString1, String paramString2)
    throws UnsupportedCharsetException
  {
    this(paramString1, g.a(g.j.a(), paramString2));
  }

  @Deprecated
  public m(String paramString1, String paramString2, String paramString3)
    throws UnsupportedEncodingException
  {
    b.a.a.a.p.a.a(paramString1, "Source string");
    String str1;
    if (paramString2 != null)
    {
      str1 = paramString2;
      if (paramString3 == null)
        break label72;
    }
    label72: for (String str2 = paramString3; ; str2 = "ISO-8859-1")
    {
      this.e = paramString1.getBytes(str2);
      a(str1 + "; charset=" + str2);
      return;
      str1 = "text/plain";
      break;
    }
  }

  public m(String paramString, Charset paramCharset)
  {
    this(paramString, g.a(g.j.a(), paramCharset));
  }

  public InputStream a()
    throws IOException
  {
    return new ByteArrayInputStream(this.e);
  }

  public void a(OutputStream paramOutputStream)
    throws IOException
  {
    b.a.a.a.p.a.a(paramOutputStream, "Output stream");
    paramOutputStream.write(this.e);
    paramOutputStream.flush();
  }

  public long b()
  {
    return this.e.length;
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    return super.clone();
  }

  public boolean d()
  {
    return true;
  }

  public boolean f()
  {
    return false;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.h.m
 * JD-Core Version:    0.6.0
 */