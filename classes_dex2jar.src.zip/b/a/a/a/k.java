package b.a.a.a;

import java.io.Closeable;
import java.io.IOException;

public abstract interface k extends Closeable
{
  public abstract void b(int paramInt);

  public abstract boolean c();

  public abstract void close()
    throws IOException;

  public abstract boolean d();

  public abstract int e();

  public abstract void f()
    throws IOException;

  public abstract m g();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.k
 * JD-Core Version:    0.6.0
 */