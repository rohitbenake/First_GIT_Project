package b.a.a.a.l;

import b.a.a.a.a.c;
import b.a.a.a.f;
import b.a.a.a.i;
import b.a.a.a.m.j;
import b.a.a.a.t;

@c
public abstract class a
  implements t
{
  protected s b = new s();

  @Deprecated
  protected j c;

  protected a()
  {
    this(null);
  }

  @Deprecated
  protected a(j paramj)
  {
    this.c = paramj;
  }

  public void a(f paramf)
  {
    this.b.a(paramf);
  }

  @Deprecated
  public void a(j paramj)
  {
    this.c = ((j)b.a.a.a.p.a.a(paramj, "HTTP parameters"));
  }

  public void a(String paramString1, String paramString2)
  {
    b.a.a.a.p.a.a(paramString1, "Header name");
    this.b.a(new b(paramString1, paramString2));
  }

  public void a(f[] paramArrayOff)
  {
    this.b.a(paramArrayOff);
  }

  public boolean a(String paramString)
  {
    return this.b.e(paramString);
  }

  public void b(f paramf)
  {
    this.b.c(paramf);
  }

  public void b(String paramString1, String paramString2)
  {
    b.a.a.a.p.a.a(paramString1, "Header name");
    this.b.c(new b(paramString1, paramString2));
  }

  public f[] b(String paramString)
  {
    return this.b.b(paramString);
  }

  public f c(String paramString)
  {
    return this.b.c(paramString);
  }

  public void c(f paramf)
  {
    this.b.b(paramf);
  }

  public f[] c_()
  {
    return this.b.b();
  }

  public f d(String paramString)
  {
    return this.b.d(paramString);
  }

  public void e(String paramString)
  {
    if (paramString == null);
    while (true)
    {
      return;
      i locali = this.b.c();
      while (locali.hasNext())
      {
        if (!paramString.equalsIgnoreCase(locali.a().c()))
          continue;
        locali.remove();
      }
    }
  }

  public i f()
  {
    return this.b.c();
  }

  public i f(String paramString)
  {
    return this.b.f(paramString);
  }

  @Deprecated
  public j g()
  {
    if (this.c == null)
      this.c = new b.a.a.a.m.b();
    return this.c;
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.l.a
 * JD-Core Version:    0.6.0
 */