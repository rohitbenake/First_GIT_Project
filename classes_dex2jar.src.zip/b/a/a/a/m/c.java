package b.a.a.a.m;

@Deprecated
public abstract interface c
{
  public static final String a_ = "http.socket.timeout";
  public static final String b_ = "http.tcp.nodelay";
  public static final String c_ = "http.socket.buffer-size";
  public static final String d_ = "http.socket.linger";
  public static final String e_ = "http.socket.reuseaddr";
  public static final String f = "http.connection.timeout";
  public static final String f_ = "http.connection.stalecheck";
  public static final String g_ = "http.connection.max-header-count";
  public static final String h = "http.connection.max-line-length";
  public static final String h_ = "http.connection.min-chunk-limit";
  public static final String i_ = "http.socket.keepalive";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.m.c
 * JD-Core Version:    0.6.0
 */