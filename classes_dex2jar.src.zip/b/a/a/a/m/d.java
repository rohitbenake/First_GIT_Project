package b.a.a.a.m;

@Deprecated
public abstract interface d
{
  public static final String j_ = "http.protocol.version";
  public static final String k_ = "http.protocol.element-charset";
  public static final String l_ = "http.protocol.content-charset";
  public static final String m_ = "http.useragent";
  public static final String n_ = "http.origin-server";
  public static final String o_ = "http.protocol.strict-transfer-encoding";
  public static final String p_ = "http.protocol.expect-continue";
  public static final String q_ = "http.protocol.wait-for-continue";
  public static final String r_ = "http.malformed.input.action";
  public static final String s_ = "http.unmappable.input.action";
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.m.d
 * JD-Core Version:    0.6.0
 */