package b.a.a.a.m;

import b.a.a.a.p.a;

@Deprecated
public abstract class f
{
  protected final j a;

  public f(j paramj)
  {
    this.a = ((j)a.a(paramj, "HTTP parameters"));
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.m.f
 * JD-Core Version:    0.6.0
 */