package b.a.a.a;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract interface n
{
  public abstract InputStream a()
    throws IOException, IllegalStateException;

  public abstract void a(OutputStream paramOutputStream)
    throws IOException;

  public abstract long b();

  @Deprecated
  public abstract void c()
    throws IOException;

  public abstract boolean d();

  public abstract boolean e();

  public abstract boolean f();

  public abstract f g();

  public abstract f h();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.n
 * JD-Core Version:    0.6.0
 */