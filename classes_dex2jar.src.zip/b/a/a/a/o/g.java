package b.a.a.a.o;

public abstract interface g
{
  public static final String o = "http.";

  public abstract Object a(String paramString);

  public abstract void a(String paramString, Object paramObject);

  public abstract Object b(String paramString);
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.o.g
 * JD-Core Version:    0.6.0
 */