package b.a.a.a;

public class p extends Exception
{
  private static final long a = -5437299376222011036L;

  public p()
  {
  }

  public p(String paramString)
  {
    super(paramString);
  }

  public p(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    initCause(paramThrowable);
  }
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.p
 * JD-Core Version:    0.6.0
 */