package b.a.a.a;

import b.a.a.a.m.j;

public abstract interface t
{
  public abstract void a(f paramf);

  @Deprecated
  public abstract void a(j paramj);

  public abstract void a(String paramString1, String paramString2);

  public abstract void a(f[] paramArrayOff);

  public abstract boolean a(String paramString);

  public abstract void b(f paramf);

  public abstract void b(String paramString1, String paramString2);

  public abstract f[] b(String paramString);

  public abstract f c(String paramString);

  public abstract void c(f paramf);

  public abstract f[] c_();

  public abstract ak d();

  public abstract f d(String paramString);

  public abstract void e(String paramString);

  public abstract i f();

  public abstract i f(String paramString);

  @Deprecated
  public abstract j g();
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.t
 * JD-Core Version:    0.6.0
 */