package b.a.a.a;

import b.a.a.a.o.g;
import java.io.IOException;

public abstract interface z
{
  public abstract void a(x paramx, g paramg)
    throws p, IOException;
}

/* Location:           C:\apktool1.5.2\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     b.a.a.a.z
 * JD-Core Version:    0.6.0
 */